var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var import_app = require("firebase/app");
var import_firestore = require("firebase/firestore");
var FB_CONFIG_PATH = import_path.default.join(process.cwd(), "firebase-applet-config.json");
var firebaseConfig = {
  apiKey: "dummy-key-for-local-build-only",
  authDomain: "dummy-project.firebaseapp.com",
  projectId: "dummy-project",
  storageBucket: "dummy-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};
var usingMockDb = false;
try {
  if (import_fs.default.existsSync(FB_CONFIG_PATH)) {
    firebaseConfig = JSON.parse(import_fs.default.readFileSync(FB_CONFIG_PATH, "utf-8"));
    console.log("[FIREBASE] Configuration loaded successfully.");
  } else {
    console.warn("[FIREBASE_WARN] firebase-applet-config.json not found. Falling back to in-memory store.");
    usingMockDb = true;
  }
} catch (configErr) {
  console.error("[FIREBASE_ERROR] Failed to load/parse firebase-applet-config.json:", configErr);
  usingMockDb = true;
}
var firebaseApp = (0, import_app.initializeApp)(firebaseConfig);
var firestoreDb = (0, import_firestore.getFirestore)(firebaseApp);
var localUsers = [];
var localPrivateMessages = [];
var localCommunities = [];
var localCommunityMessages = [];
var localVoiceStreams = /* @__PURE__ */ new Map();
function handleFirestoreError(error, operationType, path2) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {},
    operationType,
    path: path2
  };
  console.error("[FIRESTORE EXCEPTION]", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
async function testConnection() {
  if (usingMockDb) {
    console.log("[FIREBASE] Running in-memory store mode. Firebase Firestore connection checks bypassed.");
    return;
  }
  try {
    await (0, import_firestore.getDocFromServer)((0, import_firestore.doc)(firestoreDb, "test", "connection"));
    console.log("[FIREBASE] Connection to Firestore established successfully.");
  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error);
    console.warn("[FIREBASE] Connection failed:", errMsg);
    if (errMsg.includes("NOT_FOUND") || errMsg.includes("not found") || errMsg.includes("database") || errMsg.includes("5") || errMsg.includes("permission")) {
      console.warn("[FIREBASE] Firestore Database is not provisioned or could not be found. Automatically falling back to in-memory mock database to allow local execution of the application.");
      usingMockDb = true;
    }
  }
}
async function getAllUsers() {
  if (usingMockDb) {
    return localUsers;
  }
  const colPath = "users";
  try {
    const qSnapshot = await (0, import_firestore.getDocs)((0, import_firestore.collection)(firestoreDb, colPath));
    const list = [];
    qSnapshot.forEach((doc2) => {
      list.push(doc2.data());
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, "list" /* LIST */, colPath);
    return [];
  }
}
async function getUser(username) {
  const tUsername = username.toLowerCase();
  if (usingMockDb) {
    return localUsers.find((u) => u.username.toLowerCase() === tUsername) || null;
  }
  const docPath = `users/${tUsername}`;
  try {
    const dSnapshot = await (0, import_firestore.getDoc)((0, import_firestore.doc)(firestoreDb, "users", tUsername));
    if (dSnapshot.exists()) {
      return dSnapshot.data();
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, "get" /* GET */, docPath);
    return null;
  }
}
async function saveUser(user) {
  const tUsername = user.username.toLowerCase();
  if (usingMockDb) {
    const idx = localUsers.findIndex((u) => u.username.toLowerCase() === tUsername);
    if (idx > -1) {
      localUsers[idx] = user;
    } else {
      localUsers.push(user);
    }
    return;
  }
  const docPath = `users/${tUsername}`;
  try {
    await (0, import_firestore.setDoc)((0, import_firestore.doc)(firestoreDb, "users", tUsername), user);
  } catch (err) {
    handleFirestoreError(err, "write" /* WRITE */, docPath);
  }
}
async function getPrivateMessages(userA, userB) {
  const uA = userA.toLowerCase();
  const uB = userB.toLowerCase();
  if (usingMockDb) {
    return localPrivateMessages.filter(
      (m) => m.from.toLowerCase() === uA && m.to.toLowerCase() === uB || m.from.toLowerCase() === uB && m.to.toLowerCase() === uA
    );
  }
  const colPath = "privateMessages";
  try {
    const qSnapshot = await (0, import_firestore.getDocs)((0, import_firestore.collection)(firestoreDb, colPath));
    const list = [];
    qSnapshot.forEach((doc2) => {
      list.push(doc2.data());
    });
    return list.filter(
      (m) => m.from.toLowerCase() === uA && m.to.toLowerCase() === uB || m.from.toLowerCase() === uB && m.to.toLowerCase() === uA
    );
  } catch (err) {
    handleFirestoreError(err, "list" /* LIST */, colPath);
    return [];
  }
}
async function savePrivateMessage(msg) {
  if (usingMockDb) {
    localPrivateMessages.push(msg);
    return;
  }
  const docPath = `privateMessages/${msg.id}`;
  try {
    await (0, import_firestore.setDoc)((0, import_firestore.doc)(firestoreDb, "privateMessages", msg.id), msg);
  } catch (err) {
    handleFirestoreError(err, "write" /* WRITE */, docPath);
  }
}
async function getAllCommunities() {
  if (usingMockDb) {
    return localCommunities;
  }
  const colPath = "communities";
  try {
    const qSnapshot = await (0, import_firestore.getDocs)((0, import_firestore.collection)(firestoreDb, colPath));
    const list = [];
    qSnapshot.forEach((doc2) => {
      list.push(doc2.data());
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, "list" /* LIST */, colPath);
    return [];
  }
}
async function getCommunity(id) {
  if (usingMockDb) {
    return localCommunities.find((c) => c.id === id) || null;
  }
  const docPath = `communities/${id}`;
  try {
    const dSnapshot = await (0, import_firestore.getDoc)((0, import_firestore.doc)(firestoreDb, "communities", id));
    if (dSnapshot.exists()) {
      return dSnapshot.data();
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, "get" /* GET */, docPath);
    return null;
  }
}
async function saveCommunity(comm) {
  if (usingMockDb) {
    const idx = localCommunities.findIndex((c) => c.id === comm.id);
    if (idx > -1) {
      localCommunities[idx] = comm;
    } else {
      localCommunities.push(comm);
    }
    return;
  }
  const docPath = `communities/${comm.id}`;
  try {
    await (0, import_firestore.setDoc)((0, import_firestore.doc)(firestoreDb, "communities", comm.id), comm);
  } catch (err) {
    handleFirestoreError(err, "write" /* WRITE */, docPath);
  }
}
async function getCommunityMessages(communityId) {
  if (usingMockDb) {
    return localCommunityMessages.filter((m) => m.communityId === communityId);
  }
  const colPath = "communityMessages";
  try {
    const qSnapshot = await (0, import_firestore.getDocs)((0, import_firestore.collection)(firestoreDb, colPath));
    const list = [];
    qSnapshot.forEach((doc2) => {
      const data = doc2.data();
      if (data.communityId === communityId) {
        list.push(data);
      }
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, "list" /* LIST */, colPath);
    return [];
  }
}
async function saveCommunityMessage(msg) {
  if (usingMockDb) {
    localCommunityMessages.push(msg);
    return;
  }
  const docPath = `communityMessages/${msg.id}`;
  try {
    await (0, import_firestore.setDoc)((0, import_firestore.doc)(firestoreDb, "communityMessages", msg.id), msg);
  } catch (err) {
    handleFirestoreError(err, "write" /* WRITE */, docPath);
  }
}
async function getVoiceStream(communityId) {
  if (usingMockDb) {
    return localVoiceStreams.get(communityId) || [];
  }
  const docPath = `voiceStreams/${communityId}`;
  try {
    const dSnapshot = await (0, import_firestore.getDoc)((0, import_firestore.doc)(firestoreDb, "voiceStreams", communityId));
    if (dSnapshot.exists()) {
      const data = dSnapshot.data();
      return data.participants || [];
    }
    return [];
  } catch (err) {
    handleFirestoreError(err, "get" /* GET */, docPath);
    return [];
  }
}
async function saveVoiceStream(communityId, participants) {
  if (usingMockDb) {
    localVoiceStreams.set(communityId, participants);
    return;
  }
  const docPath = `voiceStreams/${communityId}`;
  try {
    await (0, import_firestore.setDoc)((0, import_firestore.doc)(firestoreDb, "voiceStreams", communityId), { communityId, participants });
  } catch (err) {
    handleFirestoreError(err, "write" /* WRITE */, docPath);
  }
}
async function bootstrapFirestore() {
  await testConnection();
  console.log("[FIREBASE] Checking if Firestore has initial data structures... (Using Mock DB: " + usingMockDb + ")");
  try {
    const users = await getAllUsers();
    if (users.length === 0) {
      console.log("[FIREBASE] Populating Firestore with live Android app defaults...");
      const defaultUsers = [
        {
          username: "admin",
          passwordHash: "ahmad199231",
          phone: "0500111222",
          avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=admin",
          status: "\u0627\u0644\u0645\u0637\u0648\u0631 \u0648\u0627\u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0644\u0644\u062A\u0637\u0628\u064A\u0642 \u{1F451}",
          points: 1e3,
          isBanned: false,
          isModerator: true,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          friends: ["\u0633\u0627\u0644\u0645", "\u0645\u0646\u0649"]
        },
        {
          username: "\u0633\u0627\u0644\u0645",
          passwordHash: "salem123",
          phone: "0551234567",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=salem",
          status: "\u0645\u062D\u0628 \u0644\u0644\u0645\u062D\u0627\u062F\u062B\u0627\u062A \u0648\u0627\u0644\u0645\u062C\u062A\u0645\u0639\u0627\u062A \u0627\u0644\u062A\u0642\u0646\u064A\u0629 \u2615",
          points: 25,
          isBanned: false,
          isModerator: false,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          friends: ["admin", "\u0645\u0646\u0649", "\u0631\u0627\u0626\u062F"]
        },
        {
          username: "\u0645\u0646\u0649",
          passwordHash: "mona123",
          phone: "0557654321",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=mona",
          status: "\u0645\u0634\u0631\u0641\u0629 \u0648\u0645\u0635\u0645\u0645\u0629 \u0648\u0627\u062C\u0647\u0627\u062A \u{1F3A8}",
          points: 40,
          isBanned: false,
          isModerator: true,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          friends: ["admin", "\u0633\u0627\u0644\u0645"]
        },
        {
          username: "\u0631\u0627\u0626\u062F",
          passwordHash: "raed123",
          phone: "0559990000",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=raed",
          status: "\u0645\u0633\u062A\u0643\u0634\u0641 \u062C\u062F\u064A\u062F \u0641\u064A \u062A\u0637\u0628\u064A\u0642 Friends!",
          points: 5,
          isBanned: false,
          isModerator: false,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          friends: ["\u0633\u0627\u0644\u0645"]
        }
      ];
      for (const u of defaultUsers) {
        await saveUser(u);
      }
      const defaultMessages = [
        {
          id: "msg1",
          from: "admin",
          to: "\u0633\u0627\u0644\u0645",
          text: "\u0623\u0647\u0644\u0627\u064B \u0628\u0643 \u064A\u0627 \u0633\u0627\u0644\u0645 \u0641\u064A \u062A\u0637\u0628\u064A\u0642 Friends! \u064A\u0633\u0639\u062F\u0646\u0627 \u0627\u0646\u0636\u0645\u0627\u0645\u0643 \u0625\u0644\u064A\u0646\u0627.",
          timestamp: new Date(Date.now() - 36e5 * 4).toISOString()
        },
        {
          id: "msg2",
          from: "\u0633\u0627\u0644\u0645",
          to: "admin",
          text: "\u0623\u0647\u0644\u0627\u064B \u0628\u0643 \u064A\u0627 \u062D\u0636\u0631\u0629 \u0627\u0644\u0645\u062F\u064A\u0631\u060C \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0631\u0627\u0626\u0639 \u0648\u0645\u0646\u0638\u0645 \u062C\u062F\u0627\u064B \u0623\u0634\u0643\u0631\u0643 \u0639\u0644\u0649 \u0627\u0644\u0625\u0628\u062F\u0627\u0639!",
          timestamp: new Date(Date.now() - 36e5 * 3.8).toISOString()
        },
        {
          id: "msg3",
          from: "\u0645\u0646\u0649",
          to: "\u0633\u0627\u0644\u0645",
          text: "\u0623\u0647\u0644\u0627\u064B \u0633\u0627\u0644\u0645\u060C \u0647\u0644 \u0642\u0645\u062A \u0628\u062A\u062C\u0631\u0628\u0629 \u0625\u0646\u0634\u0627\u0621 \u0645\u062C\u062A\u0645\u0639 \u062C\u062F\u064A\u062F \u0628\u0627\u0644\u0646\u0642\u0627\u0637 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0643\u061F",
          timestamp: new Date(Date.now() - 36e5 * 1.5).toISOString()
        }
      ];
      for (const m of defaultMessages) {
        await savePrivateMessage(m);
      }
      const defaultCommunities = [
        {
          id: "tech-world",
          name: "\u0639\u0627\u0644\u0645 \u0627\u0644\u062A\u0642\u0646\u064A\u0629 \u0648\u0627\u0644\u0628\u0631\u0645\u062C\u0629 \u{1F4F1}",
          description: "\u0645\u062C\u062A\u0645\u0639 \u064A\u062C\u0645\u0639 \u0627\u0644\u0645\u0637\u0648\u0631\u064A\u0646 \u0648\u0627\u0644\u0645\u0647\u062A\u0645\u064A\u0646 \u0628\u062C\u062F\u064A\u062F \u0627\u0644\u062A\u0643\u0646\u0648\u0644\u0648\u062C\u064A\u0627 \u0627\u0644\u0628\u0631\u0645\u062C\u064A\u0629.",
          owner: "\u0645\u0646\u0649",
          members: ["\u0645\u0646\u0649", "\u0633\u0627\u0644\u0645", "admin"],
          admins: ["\u0645\u0646\u0649", "admin"],
          banList: [],
          joinRequests: ["\u0631\u0627\u0626\u062F"],
          isBanned: false
        },
        {
          id: "coffee-club",
          name: "\u0639\u0634\u0627\u0642 \u0627\u0644\u0642\u0647\u0648\u0629 \u0648\u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u2615",
          description: "\u0645\u0633\u0627\u062D\u0629 \u0631\u0627\u0626\u0639\u0629 \u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0627\u0644\u0643\u062A\u0628 \u0627\u0644\u0645\u0641\u0636\u0644\u0629 \u0648\u0627\u0644\u062D\u062F\u064A\u062B \u0639\u0646 \u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0628\u0646.",
          owner: "\u0633\u0627\u0644\u0645",
          members: ["\u0633\u0627\u0644\u0645", "\u0645\u0646\u0649"],
          admins: ["\u0633\u0627\u0644\u0645"],
          banList: [],
          joinRequests: [],
          isBanned: false
        }
      ];
      for (const c of defaultCommunities) {
        await saveCommunity(c);
      }
      const defaultCommMessages = [
        {
          id: "cmsg1",
          communityId: "tech-world",
          sender: "\u0645\u0646\u0649",
          text: "\u0627\u0644\u0633\u0644\u0627\u0645 \u0639\u0644\u064A\u0643\u0645 \u062C\u0645\u064A\u0639\u0627\u064B! \u062A\u0645 \u0625\u0637\u0644\u0627\u0642 \u0627\u0644\u0628\u062B \u0627\u0644\u0635\u0648\u062A\u064A \u0627\u0644\u0622\u0646 \u0644\u0645\u0646\u0627\u0642\u0634\u0629 \u062A\u062D\u062F\u064A\u062B\u0627\u062A React 19.",
          timestamp: new Date(Date.now() - 36e5 * 2).toISOString()
        },
        {
          id: "cmsg2",
          communityId: "tech-world",
          sender: "\u0633\u0627\u0644\u0645",
          text: "\u0648\u0639\u0644\u064A\u0643\u0645 \u0627\u0644\u0633\u0644\u0627\u0645! \u0633\u0623\u0646\u0636\u0645 \u062D\u0627\u0644\u0627\u064B \u0644\u0644\u0628\u062B \u0627\u0644\u0635\u0648\u062A\u064A\u060C \u0645\u0648\u0636\u0648\u0639 \u0645\u0645\u062A\u0627\u0632 \u062C\u062F\u0627\u064B.",
          timestamp: new Date(Date.now() - 36e5 * 1.8).toISOString()
        }
      ];
      for (const cm of defaultCommMessages) {
        await saveCommunityMessage(cm);
      }
      const defaultVoiceStreams = {
        "tech-world": [
          { username: "\u0645\u0646\u0649", isSpeaking: true, isMuted: false, canSpeak: true },
          { username: "\u0633\u0627\u0644\u0645", isSpeaking: false, isMuted: true, canSpeak: true }
        ]
      };
      for (const [k, v] of Object.entries(defaultVoiceStreams)) {
        await saveVoiceStream(k, v);
      }
      console.log("[FIREBASE] Bootstrapping fresh Firestore database completed.");
    } else {
      const admin = await getUser("admin");
      if (!admin) {
        await saveUser({
          username: "admin",
          passwordHash: "ahmad199231",
          phone: "0500111222",
          avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=admin",
          status: "\u0627\u0644\u0645\u0637\u0648\u0631 \u0648\u0627\u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0644\u0644\u062A\u0637\u0628\u064A\u0642 \u{1F451}",
          points: 1e3,
          isBanned: false,
          isModerator: true,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          friends: []
        });
      } else {
        admin.passwordHash = "ahmad199231";
        admin.isModerator = true;
        admin.isBanned = false;
        await saveUser(admin);
      }
    }
  } catch (err) {
    console.error("[FIREBASE] Bootstrapping failed:", err);
  }
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  bootstrapFirestore().catch((err) => {
    console.error("[FIREBASE] Background bootstrap failed:", err);
  });
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString(), engine: "firestore" });
  });
  app.post("/api/register", async (req, res) => {
    try {
      const { username, password, phone, avatar, status } = req.body;
      if (!username || !password || !phone) {
        return res.status(400).json({ error: "\u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0644 (\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u060C \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u060C \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641) \u0625\u062C\u0628\u0627\u0631\u064A\u0629!" });
      }
      const trimmedUsername = username.trim();
      if (trimmedUsername.toLowerCase() === "admin") {
        return res.status(400).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0628\u0627\u0633\u0645 admin \u0644\u0623\u0646\u0647 \u062D\u0633\u0627\u0628 \u0645\u062D\u0645\u064A!" });
      }
      const exists = await getUser(trimmedUsername);
      if (exists) {
        return res.status(400).json({ error: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0647\u0630\u0627 \u0645\u0633\u062C\u0644 \u0628\u0627\u0644\u0641\u0639\u0644!" });
      }
      const newUser = {
        username: trimmedUsername,
        passwordHash: password,
        phone: phone.trim(),
        avatar: avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(trimmedUsername)}`,
        status: status || "\u0639\u0636\u0648 \u062C\u062F\u064A\u062F \u0641\u064A \u0645\u062C\u062A\u0645\u0639\u0627\u062A Friends \u2728",
        points: 0,
        isBanned: false,
        isModerator: false,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        friends: ["admin"]
      };
      const adminInst = await getUser("admin");
      if (adminInst) {
        if (!adminInst.friends) adminInst.friends = [];
        if (!adminInst.friends.includes(trimmedUsername)) {
          adminInst.friends.push(trimmedUsername);
          await saveUser(adminInst);
        }
      }
      await saveUser(newUser);
      res.json({
        success: true,
        user: {
          username: newUser.username,
          phone: newUser.phone,
          avatar: newUser.avatar,
          status: newUser.status,
          points: newUser.points,
          isBanned: newUser.isBanned,
          isModerator: newUser.isModerator,
          friends: newUser.friends
        }
      });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u062A\u0633\u062C\u064A\u0644 \u0645\u0633\u062A\u062E\u062F\u0645 \u062C\u062F\u064A\u062F" });
    }
  });
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ error: "\u064A\u0631\u062C\u0649 \u062A\u062D\u062F\u064A\u062F \u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631!" });
      }
      const user = await getUser(username.trim());
      if (!user) {
        return res.status(400).json({ error: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      }
      if (user.passwordHash !== password) {
        return res.status(400).json({ error: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629!" });
      }
      if (user.isBanned) {
        return res.status(403).json({ error: "\u062A\u0645 \u062D\u0638\u0631 \u062D\u0633\u0627\u0628\u0643 \u0645\u0646 \u0642\u0628\u0644 \u0627\u0644\u0625\u062F\u0627\u0631\u0629!" });
      }
      res.json({
        success: true,
        user: {
          username: user.username,
          phone: user.phone,
          avatar: user.avatar,
          status: user.status,
          points: user.points,
          isBanned: user.isBanned,
          isModerator: user.isModerator,
          friends: user.friends || []
        }
      });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u0644\u062D\u0633\u0627\u0628" });
    }
  });
  app.post("/api/recover", async (req, res) => {
    try {
      const { phone, username, newPassword } = req.body;
      if (!phone || !username || !newPassword) {
        return res.status(400).json({ error: "\u064A\u0631\u062C\u0649 \u0625\u062F\u062E\u0627\u0644 \u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629!" });
      }
      const user = await getUser(username.trim());
      if (!user || user.phone !== phone.trim()) {
        return res.status(400).json({ error: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u062A\u0637\u0627\u0628\u0642 \u0645\u0639 \u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0627\u0644\u0645\u062F\u062E\u0644\u064A\u0646!" });
      }
      if (user.username.toLowerCase() === "admin") {
        return res.status(403).json({ error: "\u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D \u0628\u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u062D\u0633\u0627\u0628 \u0627\u0644\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0639\u0628\u0631 \u0627\u0644\u0647\u0627\u062A\u0641!" });
      }
      user.passwordHash = newPassword;
      await saveUser(user);
      res.json({ success: true, message: "\u062A\u0645 \u062A\u063A\u064A\u064A\u0631 \u0648\u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0628\u0646\u062C\u0627\u062D!" });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644\u062A \u0627\u0644\u0627\u0633\u062A\u0639\u0627\u062F\u0629" });
    }
  });
  app.post("/api/update-profile", async (req, res) => {
    try {
      const { username, avatar, status, phone, password } = req.body;
      const user = await getUser(username.trim());
      if (!user) {
        return res.status(404).json({ error: "\u0627\u0644\u0639\u0636\u0648 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      }
      if (avatar) user.avatar = avatar;
      if (status !== void 0) user.status = status;
      if (phone) user.phone = phone.trim();
      if (password) {
        if (user.username.toLowerCase() === "admin") {
          return res.status(403).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0639\u062F\u064A\u0644 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0627\u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0645\u0646 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0639\u0627\u0645\u0629!" });
        }
        user.passwordHash = password;
      }
      await saveUser(user);
      res.json({
        success: true,
        user: {
          username: user.username,
          phone: user.phone,
          avatar: user.avatar,
          status: user.status,
          points: user.points,
          isBanned: user.isBanned,
          isModerator: user.isModerator,
          friends: user.friends || []
        }
      });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0627\u0644\u062A\u0639\u062F\u064A\u0644" });
    }
  });
  app.get("/api/users", async (req, res) => {
    try {
      const users = await getAllUsers();
      const basicUsers = users.map((u) => ({
        username: u.username,
        avatar: u.avatar,
        status: u.status,
        points: u.points,
        isBanned: u.isBanned,
        isModerator: u.isModerator,
        createdAt: u.createdAt
      }));
      res.json(basicUsers);
    } catch (e) {
      res.status(500).json([]);
    }
  });
  app.get("/api/user/:username", async (req, res) => {
    try {
      const user = await getUser(req.params.username);
      if (!user) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      }
      res.json({
        username: user.username,
        avatar: user.avatar,
        status: user.status,
        points: user.points,
        isBanned: user.isBanned,
        isModerator: user.isModerator,
        createdAt: user.createdAt,
        friends: user.friends || []
      });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u062C\u0644\u0628 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645" });
    }
  });
  app.post("/api/friends/toggle", async (req, res) => {
    try {
      const { username, targetFriend } = req.body;
      const user = await getUser(username);
      const friendObj = await getUser(targetFriend);
      if (!user || !friendObj) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      }
      if (!user.friends) user.friends = [];
      if (!friendObj.friends) friendObj.friends = [];
      const index = user.friends.indexOf(friendObj.username);
      if (index > -1) {
        user.friends.splice(index, 1);
        const indexBack = friendObj.friends.indexOf(user.username);
        if (indexBack > -1) {
          friendObj.friends.splice(indexBack, 1);
        }
      } else {
        user.friends.push(friendObj.username);
        if (!friendObj.friends.includes(user.username)) {
          friendObj.friends.push(user.username);
        }
      }
      await saveUser(user);
      await saveUser(friendObj);
      res.json({ success: true, friends: user.friends });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644\u062A \u0643\u0633\u0631 \u0627\u0644\u0635\u062F\u0627\u0642\u0629" });
    }
  });
  app.get("/api/messages/:userA/:userB", async (req, res) => {
    try {
      const chats = await getPrivateMessages(req.params.userA, req.params.userB);
      res.json(chats);
    } catch (e) {
      res.json([]);
    }
  });
  app.post("/api/messages", async (req, res) => {
    try {
      const { from, to, text } = req.body;
      if (!from || !to || !text) {
        return res.status(400).json({ error: "\u0628\u0631\u062C\u0627\u0621 \u062A\u0648\u0641\u064A\u0631 \u0643\u0644 \u0645\u0646 \u0627\u0644\u0645\u0631\u0633\u0644 \u0648\u0627\u0644\u0645\u0633\u062A\u0642\u0628\u0644 \u0648\u0646\u0635 \u0627\u0644\u0631\u0633\u0627\u0644\u0629!" });
      }
      const sender = await getUser(from);
      if (sender?.isBanned) {
        return res.status(403).json({ error: "\u0623\u0646\u062A \u0645\u062D\u0638\u0648\u0631 \u0645\u0646 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0634\u0627\u062A!" });
      }
      const newMsg = {
        id: "msg_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
        from,
        to,
        text,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      await savePrivateMessage(newMsg);
      if (sender) {
        if (!sender.friends) sender.friends = [];
        if (!sender.friends.includes(to)) {
          sender.friends.push(to);
          await saveUser(sender);
        }
      }
      const receiver = await getUser(to);
      if (receiver) {
        if (!receiver.friends) receiver.friends = [];
        if (!receiver.friends.includes(from)) {
          receiver.friends.push(from);
          await saveUser(receiver);
        }
      }
      res.json(newMsg);
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0633\u0627\u0644\u0629" });
    }
  });
  app.get("/api/communities", async (req, res) => {
    try {
      const comms = await getAllCommunities();
      res.json(comms);
    } catch (e) {
      res.json([]);
    }
  });
  app.post("/api/communities/create", async (req, res) => {
    try {
      const { name, description, owner } = req.body;
      if (!name || !owner) {
        return res.status(400).json({ error: "\u0627\u0633\u0645 \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0648\u0635\u0627\u062D\u0628 \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0645\u0637\u0644\u0648\u0628\u064A\u0646!" });
      }
      const ownerUser = await getUser(owner);
      if (!ownerUser) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0645\u0630\u0643\u0648\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      }
      if (ownerUser.isBanned) {
        return res.status(403).json({ error: "\u0635\u0627\u062D\u0628 \u0627\u0644\u062D\u0633\u0627\u0628 \u0645\u062D\u0638\u0648\u0631 \u0648\u0644\u0627 \u064A\u0645\u0643\u0646\u0647 \u062A\u0641\u0639\u064A\u0644 \u0645\u062C\u062A\u0645\u0639\u0627\u062A!" });
      }
      if (ownerUser.points < 10 && ownerUser.username.toLowerCase() !== "admin") {
        return res.status(400).json({ error: "\u0644\u064A\u0633 \u0644\u062F\u064A\u0643 \u0646\u0642\u0627\u0637 \u0643\u0627\u0641\u064A\u0629 \u0644\u0625\u0646\u0634\u0627\u0621 \u0645\u062C\u062A\u0645\u0639! \u062A\u062D\u062A\u0627\u062C \u0644\u0640 10 \u0646\u0642\u0627\u0637 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u0645\u0646 \u0645\u062F\u064A\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642." });
      }
      if (ownerUser.username.toLowerCase() !== "admin") {
        ownerUser.points -= 10;
        await saveUser(ownerUser);
      }
      const communityId = "comm_" + Date.now();
      const newComm = {
        id: communityId,
        name: name.trim(),
        description: description || "\u0644\u0627 \u064A\u0648\u062C\u062F \u0648\u0635\u0641 \u0645\u062A\u0648\u0641\u0631 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0628\u0639\u062F.",
        owner: ownerUser.username,
        members: [ownerUser.username],
        admins: [ownerUser.username],
        banList: [],
        joinRequests: [],
        isBanned: false
      };
      await saveCommunity(newComm);
      res.json({ success: true, community: newComm, pointsRemaining: ownerUser.points });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0639\u0630\u0631\u0627\u064B \u062A\u0639\u0630\u0631 \u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0645\u062C\u062A\u0645\u0639" });
    }
  });
  app.post("/api/communities/join-request", async (req, res) => {
    try {
      const { communityId, username } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      if (comm.banList.includes(username)) {
        return res.status(403).json({ error: "\u0623\u0646\u062A \u0645\u062D\u0638\u0648\u0631 \u0645\u0646 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u062C\u062A\u0645\u0639!" });
      }
      if (comm.members.includes(username)) {
        return res.status(400).json({ error: "\u0623\u0646\u062A \u0639\u0636\u0648 \u0628\u0627\u0644\u0641\u0639\u0644 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u062C\u062A\u0645\u0639!" });
      }
      if (comm.joinRequests.includes(username)) {
        return res.status(400).json({ error: "\u0644\u0642\u062F \u0623\u0631\u0633\u0644\u062A \u0637\u0644\u0628 \u0627\u0646\u0636\u0645\u0627\u0645 \u0645\u0633\u0628\u0642\u0627\u064B \u0648\u0647\u0648 \u0642\u064A\u062F \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629!" });
      }
      comm.joinRequests.push(username);
      await saveCommunity(comm);
      res.json({ success: true, message: "\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0644\u0645\u0627\u0644\u0643\u064A \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0628\u0646\u062C\u0627\u062D." });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645" });
    }
  });
  app.post("/api/communities/manage-request", async (req, res) => {
    try {
      const { communityId, requester, action, actor } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      const isActorAuthorized = comm.admins.includes(actor) || comm.owner === actor;
      if (!isActorAuthorized) {
        return res.status(403).json({ error: "\u0644\u064A\u0633 \u0644\u062F\u064A\u0643 \u0635\u0644\u0627\u062D\u064A\u0629 \u0644\u0625\u062F\u0627\u0631\u0629 \u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645!" });
      }
      comm.joinRequests = comm.joinRequests.filter((r) => r !== requester);
      if (action === "approve") {
        if (!comm.members.includes(requester)) {
          comm.members.push(requester);
        }
      }
      await saveCommunity(comm);
      res.json({ success: true, community: comm });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0627\u0644\u062A\u062D\u0643\u0645" });
    }
  });
  app.post("/api/communities/kick", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      const isAdmin = comm.admins.includes(actor) || comm.owner === actor;
      if (!isAdmin) return res.status(403).json({ error: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0644\u0643!" });
      if (target === comm.owner) {
        return res.status(403).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0632\u0627\u0644\u0629 \u0645\u0627\u0644\u0643 \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0627\u0644\u0623\u0635\u0644\u064A!" });
      }
      if (comm.admins.includes(target) && actor !== comm.owner) {
        return res.status(403).json({ error: "\u0628\u0635\u0641\u062A\u0643 \u0645\u0634\u0631\u0641\u0627\u064B\u060C \u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u0637\u0631\u062F \u0645\u0634\u0631\u0641 \u0622\u062E\u0631! \u0641\u0642\u0637 \u0627\u0644\u0645\u0627\u0644\u0643 \u064A\u0645\u0643\u0646\u0647 \u0630\u0644\u0643." });
      }
      comm.members = comm.members.filter((m) => m !== target);
      comm.admins = comm.admins.filter((m) => m !== target);
      await saveCommunity(comm);
      const vs = await getVoiceStream(communityId);
      const vsFilter = vs.filter((p) => p.username !== target);
      await saveVoiceStream(communityId, vsFilter);
      res.json({ success: true, community: comm });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0627\u0644\u0637\u0631\u062F" });
    }
  });
  app.post("/api/communities/ban-member", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      const isAdmin = comm.admins.includes(actor) || comm.owner === actor;
      if (!isAdmin) return res.status(403).json({ error: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0644\u0643!" });
      if (target === comm.owner) {
        return res.status(403).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u062D\u0638\u0631 \u0645\u0646\u0634\u0626 \u0648\u0645\u0627\u0644\u0643 \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0627\u0644\u0623\u0635\u0644\u064A!" });
      }
      if (comm.admins.includes(target) && actor !== comm.owner) {
        return res.status(403).json({ error: "\u0627\u0644\u0645\u0634\u0631\u0641 \u0644\u0627 \u064A\u0633\u062A\u0637\u064A\u0639 \u062D\u0638\u0631 \u0645\u0634\u0631\u0641\u0627\u064B \u0622\u062E\u0631. \u0641\u0642\u0637 \u0645\u0646\u0634\u0626 \u0627\u0644\u063A\u0631\u0641\u0629 \u064A\u0633\u062A\u0637\u064A\u0639 \u0630\u0644\u0643." });
      }
      comm.members = comm.members.filter((m) => m !== target);
      comm.admins = comm.admins.filter((m) => m !== target);
      if (!comm.banList.includes(target)) {
        comm.banList.push(target);
      }
      await saveCommunity(comm);
      const vs = await getVoiceStream(communityId);
      const vsFilter = vs.filter((p) => p.username !== target);
      await saveVoiceStream(communityId, vsFilter);
      res.json({ success: true, community: comm });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0635\u0644 \u0627\u0644\u062D\u0638\u0631" });
    }
  });
  app.post("/api/communities/promote", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      if (comm.owner !== actor) {
        return res.status(403).json({ error: "\u0641\u0642\u0637 \u0635\u0627\u062D\u0628 \u0627\u0644\u063A\u0631\u0641\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u064A\u0633\u062A\u0637\u064A\u0639 \u062A\u0639\u064A\u064A\u0646 \u0645\u0634\u0631\u0641\u064A\u0646 (\u0623\u062F\u0645\u0646)!" });
      }
      if (!comm.members.includes(target)) {
        return res.status(400).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0645\u0631\u0634\u062D \u0644\u064A\u0633 \u0639\u0636\u0648\u0627\u064B \u0641\u064A \u0627\u0644\u0645\u062C\u062A\u0645\u0639!" });
      }
      if (!comm.admins.includes(target)) {
        comm.admins.push(target);
      }
      await saveCommunity(comm);
      res.json({ success: true, community: comm });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0627\u0644\u062A\u0631\u0642\u064A\u0629" });
    }
  });
  app.post("/api/communities/demote", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      if (comm.owner !== actor) {
        return res.status(403).json({ error: "\u0641\u0642\u0637 \u0635\u0627\u062D\u0628 \u0627\u0644\u063A\u0631\u0641\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u064A\u0633\u062A\u0637\u064A\u0639 \u0625\u0632\u0627\u0644\u0629 \u0645\u0634\u0631\u0641\u064A\u0646!" });
      }
      if (target === comm.owner) {
        return res.status(400).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0639\u062F\u064A\u0644 \u0631\u062A\u0628\u0629 \u0645\u0646\u0634\u0626 \u0627\u0644\u063A\u0631\u0641\u0629 \u0627\u0644\u0623\u0635\u0644\u064A!" });
      }
      comm.admins = comm.admins.filter((a) => a !== target);
      await saveCommunity(comm);
      res.json({ success: true, community: comm });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644\u062A \u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u0639\u0632\u0644" });
    }
  });
  app.post("/api/communities/leave", async (req, res) => {
    try {
      const { communityId, username } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      if (comm.owner === username) {
        return res.status(400).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0645\u063A\u0627\u062F\u0631\u062A\u0647 \u0646\u0647\u0627\u0626\u064A\u0627\u064B! \u064A\u0645\u0643\u0646\u0643 \u062D\u0630\u0641\u0647 \u062A\u0645\u0627\u0645\u0627\u064B \u0639\u0628\u0631 \u0627\u0644\u062F\u0639\u0645." });
      }
      comm.members = comm.members.filter((m) => m !== username);
      comm.admins = comm.admins.filter((m) => m !== username);
      await saveCommunity(comm);
      const vs = await getVoiceStream(communityId);
      const vsFilter = vs.filter((p) => p.username !== username);
      await saveVoiceStream(communityId, vsFilter);
      res.json({ success: true, community: comm });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0627\u0644\u062E\u0631\u0648\u062C" });
    }
  });
  app.get("/api/communities/:communityId/messages", async (req, res) => {
    try {
      const msgs = await getCommunityMessages(req.params.communityId);
      res.json(msgs);
    } catch (e) {
      res.json([]);
    }
  });
  app.post("/api/communities/messages", async (req, res) => {
    try {
      const { communityId, sender, text } = req.body;
      if (!communityId || !sender || !text) {
        return res.status(400).json({ error: "\u062A\u0623\u0643\u062F \u0645\u0646 \u062A\u0648\u0641\u064A\u0631 \u0631\u0642\u0645 \u0627\u0644\u0645\u062C\u062A\u0645\u0639\u060C \u0627\u0644\u0645\u0631\u0633\u0644\u060C \u0648\u0646\u0635 \u0627\u0644\u0631\u0633\u0627\u0644\u0629!" });
      }
      const userObj = await getUser(sender);
      if (userObj?.isBanned) {
        return res.status(403).json({ error: "\u0623\u0646\u062A \u0645\u062D\u0638\u0648\u0631 \u0645\u0646 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0648\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0633\u0627\u0626\u0644!" });
      }
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0644\u0645 \u064A\u0639\u062F \u0645\u0648\u062C\u0648\u062F\u0627\u064B!" });
      if (!comm.members.includes(sender)) {
        return res.status(403).json({ error: "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0646\u0636\u0645 \u0644\u0644\u0645\u062C\u062A\u0645\u0639 \u0623\u0648\u0644\u0627\u064B \u0644\u062A\u062A\u0645\u0643\u0646 \u0645\u0646 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0633\u0627\u0626\u0644!" });
      }
      const newMsg = {
        id: "cm_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
        communityId,
        sender,
        text,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      await saveCommunityMessage(newMsg);
      res.json(newMsg);
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0645\u0634\u0627\u0631\u0643\u0629 \u0627\u0644\u0631\u0633\u0627\u0644\u0629" });
    }
  });
  app.get("/api/voice-stream/:communityId", async (req, res) => {
    try {
      const communityId = req.params.communityId;
      const participants = await getVoiceStream(communityId);
      res.json({ communityId, participants });
    } catch (e) {
      res.json({ communityId: req.params.communityId, participants: [] });
    }
  });
  app.post("/api/voice-stream/join", async (req, res) => {
    try {
      const { communityId, username } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      if (!comm.members.includes(username)) {
        return res.status(403).json({ error: "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0639\u0636\u0648\u0627\u064B \u0641\u064A \u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u0644\u062A\u0646\u0636\u0645 \u0644\u0644\u0628\u062B \u0627\u0644\u0635\u0648\u062A\u064A!" });
      }
      const stream = await getVoiceStream(communityId);
      const existingIdx = stream.findIndex((p) => p.username === username);
      if (existingIdx === -1) {
        stream.push({
          username,
          isSpeaking: false,
          isMuted: false,
          canSpeak: true
        });
        await saveVoiceStream(communityId, stream);
      }
      res.json({ success: true, participants: stream });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u062A\u0639\u0630\u0631 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0644\u0644\u0628\u062B" });
    }
  });
  app.post("/api/voice-stream/leave", async (req, res) => {
    try {
      const { communityId, username } = req.body;
      const stream = await getVoiceStream(communityId);
      const filtered = stream.filter((p) => p.username !== username);
      await saveVoiceStream(communityId, filtered);
      res.json({ success: true, participants: filtered });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u062A\u0639\u0630\u0631 \u062A\u0631\u0643 \u0627\u0644\u0628\u062B" });
    }
  });
  app.post("/api/voice-stream/toggle-mute", async (req, res) => {
    try {
      const { communityId, username, isMuted } = req.body;
      const stream = await getVoiceStream(communityId);
      const participant = stream.find((p) => p.username === username);
      if (participant) {
        participant.isMuted = isMuted;
        if (isMuted) {
          participant.isSpeaking = false;
        }
        await saveVoiceStream(communityId, stream);
      }
      res.json({ success: true, participants: stream });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u062E\u0637\u0623 \u0643\u062A\u0645 \u0627\u0644\u0635\u0648\u062A" });
    }
  });
  app.post("/api/voice-stream/simulate-speaking", async (req, res) => {
    try {
      const { communityId, username, isSpeaking } = req.body;
      const stream = await getVoiceStream(communityId);
      const participant = stream.find((p) => p.username === username);
      if (participant) {
        if (!participant.isMuted && participant.canSpeak) {
          participant.isSpeaking = isSpeaking;
        } else {
          participant.isSpeaking = false;
        }
        await saveVoiceStream(communityId, stream);
      }
      res.json({ success: true, participants: stream });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
  app.post("/api/voice-stream/control", async (req, res) => {
    try {
      const { communityId, target, action, actor } = req.body;
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      const isOwnerOrAdmin = comm.owner === actor || comm.admins.includes(actor);
      if (!isOwnerOrAdmin) {
        return res.status(403).json({ error: "\u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u0628\u062B \u0627\u0644\u0635\u0648\u062A\u064A \u0645\u062A\u0627\u062D\u0629 \u0644\u0644\u0645\u0627\u0644\u0643 \u0648\u0627\u0644\u0645\u0634\u0631\u0641\u064A\u0646 \u0641\u0642\u0637!" });
      }
      if (target === comm.owner && actor !== comm.owner) {
        return res.status(403).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u062A\u062E\u0627\u0630 \u0625\u062C\u0631\u0627\u0621 \u0635\u0648\u062A\u064A \u0628\u062D\u0642 \u0645\u0627\u0644\u0643 \u0627\u0644\u063A\u0631\u0641\u0629 \u0627\u0644\u0623\u0635\u0644\u064A!" });
      }
      const stream = await getVoiceStream(communityId);
      let nextStream = [...stream];
      const participant = nextStream.find((p) => p.username === target);
      if (participant) {
        switch (action) {
          case "mute":
            participant.isMuted = true;
            participant.isSpeaking = false;
            break;
          case "unmute":
            participant.isMuted = false;
            break;
          case "allow":
            participant.canSpeak = true;
            break;
          case "block":
            participant.canSpeak = false;
            participant.isSpeaking = false;
            participant.isMuted = true;
            break;
          case "kick":
            nextStream = nextStream.filter((p) => p.username !== target);
            break;
        }
        await saveVoiceStream(communityId, nextStream);
      }
      res.json({ success: true, participants: nextStream });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644 \u0627\u0644\u062A\u062D\u0643\u0645 \u0628\u0627\u0644\u0635\u0648\u062A" });
    }
  });
  app.post("/api/admin/grant-points", async (req, res) => {
    try {
      const { targetUsername, pointsAmount, actorAdmin } = req.body;
      const actor = await getUser(actorAdmin);
      if (!actor) {
        return res.status(403).json({ error: "\u0627\u0644\u0645\u0633\u0624\u0648\u0644 \u063A\u064A\u0631 \u0645\u062A\u0648\u0627\u062C\u062F \u0639\u0644\u0649 \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A." });
      }
      const isOriginalAdmin = actor.username.toLowerCase() === "admin";
      if (!isOriginalAdmin && !actor.isModerator) {
        return res.status(403).json({ error: "\u0644\u064A\u0633 \u0644\u062F\u064A\u0643 \u0635\u0644\u0627\u062D\u064A\u0629 \u0644\u0648\u062D\u0629 \u0627\u0644\u0625\u062F\u0627\u0631\u0629!" });
      }
      const amt = parseInt(pointsAmount, 10);
      if (isNaN(amt) || amt <= 0) {
        return res.status(400).json({ error: "\u064A\u0631\u062C\u0649 \u062A\u062D\u062F\u064A\u062F \u0643\u0645\u064A\u0629 \u0646\u0642\u0627\u0637 \u0635\u062D\u064A\u062D\u0629!" });
      }
      const targetUser = await getUser(targetUsername);
      if (!targetUser) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u0647\u062F\u0641 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0644\u062A\u0631\u0642\u064A\u0629 \u0646\u0642\u0627\u0637\u0647!" });
      }
      targetUser.points += amt;
      await saveUser(targetUser);
      res.json({ success: true, targetUser: { username: targetUser.username, points: targetUser.points } });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644\u062A \u0627\u0644\u0639\u0645\u0644\u064A\u0629" });
    }
  });
  app.post("/api/admin/toggle-user-ban", async (req, res) => {
    try {
      const { targetUsername, isBanned, actorAdmin } = req.body;
      const actor = await getUser(actorAdmin);
      if (!actor || !actor.isModerator && actor.username.toLowerCase() !== "admin") {
        return res.status(403).json({ error: "\u0644\u064A\u0633 \u0644\u062F\u064A\u0643 \u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0644\u0647\u0630\u0627 \u0627\u0644\u0625\u062C\u0631\u0627\u0621!" });
      }
      if (targetUsername.toLowerCase() === "admin") {
        return res.status(403).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u062D\u0638\u0631 \u062D\u0633\u0627\u0628 \u0627\u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0631\u0626\u064A\u0633\u064A (admin)!" });
      }
      const targetUser = await getUser(targetUsername);
      if (!targetUser) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u0647\u062F\u0641 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      }
      if (targetUser.isModerator && actor.username.toLowerCase() !== "admin") {
        return res.status(403).json({ error: "\u0627\u0644\u0645\u0634\u0631\u0641\u0648\u0646 \u0644\u0627 \u064A\u0645\u0643\u0646\u0647\u0645 \u062D\u0638\u0631 \u0645\u0634\u0631\u0641\u064A\u0646 \u0622\u062E\u0631\u064A\u0646 \u0644\u0644\u0645\u0648\u0642\u0639. \u0627\u0644\u0645\u0627\u0644\u0643 \u0641\u0642\u0637 \u064A\u0633\u062A\u0637\u064A\u0639 \u0630\u0644\u0643!" });
      }
      targetUser.isBanned = isBanned;
      await saveUser(targetUser);
      res.json({ success: true, username: targetUser.username, isBanned: targetUser.isBanned });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644\u062A \u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u062D\u0638\u0631" });
    }
  });
  app.post("/api/admin/toggle-community-ban", async (req, res) => {
    try {
      const { communityId, isBanned, actorAdmin } = req.body;
      const actor = await getUser(actorAdmin);
      if (!actor || !actor.isModerator && actor.username.toLowerCase() !== "admin") {
        return res.status(403).json({ error: "\u0644\u064A\u0633 \u0644\u062F\u064A\u0643 \u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0644\u0647\u0630\u0627 \u0627\u0644\u0625\u062C\u0631\u0627\u0621!" });
      }
      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "\u0627\u0644\u0645\u062C\u062A\u0645\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0639\u0644\u0649 \u0627\u0644\u062E\u0627\u062F\u0645!" });
      comm.isBanned = isBanned;
      await saveCommunity(comm);
      res.json({ success: true, communityId, isBanned });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644\u062A \u0627\u0644\u0639\u0645\u0644\u064A\u0629" });
    }
  });
  app.post("/api/admin/manage-moderator", async (req, res) => {
    try {
      const { targetUsername, isModerator, actorAdmin } = req.body;
      if (actorAdmin.toLowerCase() !== "admin") {
        return res.status(403).json({ error: "\u0641\u0642\u0637 \u062D\u0633\u0627\u0628 \u0627\u0644\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0648\u0627\u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0623\u0635\u0644\u064A (admin) \u064A\u0633\u062A\u0637\u064A\u0639 \u062A\u0639\u064A\u064A\u0646/\u0639\u0632\u0644 \u0645\u0633\u0624\u0648\u0644 \u0639\u0627\u0645 \u0644\u0644\u0645\u0648\u0642\u0639!" });
      }
      const targetUser = await getUser(targetUsername);
      if (!targetUser) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0645\u0639\u0646\u064A \u0628\u0637\u0644\u0628 \u0627\u0644\u0625\u062F\u0627\u0631\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F!" });
      }
      if (targetUser.username.toLowerCase() === "admin") {
        return res.status(400).json({ error: "\u0627\u0644\u0645\u0637\u0648\u0631 \u0648\u0627\u0644\u0645\u0627\u0644\u0643 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0644\u064A\u0633 \u0628\u062D\u0627\u062C\u0629 \u0644\u062A\u0639\u064A\u064A\u0646 \u0623\u0648 \u062A\u0639\u062F\u064A\u0644 \u0635\u0644\u0627\u062D\u064A\u0627\u062A!" });
      }
      targetUser.isModerator = isModerator;
      await saveUser(targetUser);
      res.json({ success: true, username: targetUser.username, isModerator: targetUser.isModerator });
    } catch (e) {
      res.status(500).json({ error: e.message || "\u0641\u0634\u0644\u062A \u0627\u0644\u0639\u0645\u0644\u064A\u0629" });
    }
  });
  app.post("/api/voice-stream/ping", (req, res) => {
    res.json({ success: true });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[FRIENDS SERVER] Live Android server running on http://localhost:${PORT}`);
  });
}
startServer();
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
//# sourceMappingURL=server.cjs.map
