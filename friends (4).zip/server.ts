/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { initializeApp } from "firebase/app";
import { 
  getFirestore, doc, getDoc, getDocs, setDoc, updateDoc, 
  deleteDoc, collection, query, where, getDocFromServer 
} from "firebase/firestore";

interface DBUser {
  username: string;
  passwordHash: string;
  phone: string;
  avatar: string;
  status: string;
  points: number;
  isBanned: boolean;
  isModerator: boolean;
  createdAt: string;
  friends: string[];
}

interface DBPrivateMessage {
  id: string;
  from: string;
  to: string;
  text: string;
  timestamp: string;
}

interface DBCommunity {
  id: string;
  name: string;
  description: string;
  owner: string;
  members: string[];
  admins: string[];
  banList: string[];
  joinRequests: string[];
  isBanned: boolean;
}

interface DBCommunityMessage {
  id: string;
  communityId: string;
  sender: string;
  text: string;
  timestamp: string;
}

interface DBVoiceStreamParticipant {
  username: string;
  isSpeaking: boolean;
  isMuted: boolean;
  canSpeak: boolean;
}

// 1. Firebase Service Initialization
const FB_CONFIG_PATH = path.join(process.cwd(), "firebase-applet-config.json");
let firebaseConfig = {
  apiKey: "dummy-key-for-local-build-only",
  authDomain: "dummy-project.firebaseapp.com",
  projectId: "dummy-project",
  storageBucket: "dummy-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};

let usingMockDb = false;
try {
  if (fs.existsSync(FB_CONFIG_PATH)) {
    firebaseConfig = JSON.parse(fs.readFileSync(FB_CONFIG_PATH, "utf-8"));
    console.log("[FIREBASE] Configuration loaded successfully.");
  } else {
    console.warn("[FIREBASE_WARN] firebase-applet-config.json not found. Falling back to in-memory store.");
    usingMockDb = true;
  }
} catch (configErr) {
  console.error("[FIREBASE_ERROR] Failed to load/parse firebase-applet-config.json:", configErr);
  usingMockDb = true;
}

const firebaseApp = initializeApp(firebaseConfig);
const firestoreDb = getFirestore(firebaseApp);

// Local in-memory backing lists for zero-Firebase execution (e.g., GitHub Actions, local offline, phone test)
const localUsers: DBUser[] = [];
const localPrivateMessages: DBPrivateMessage[] = [];
const localCommunities: DBCommunity[] = [];
const localCommunityMessages: DBCommunityMessage[] = [];
const localVoiceStreams = new Map<string, DBVoiceStreamParticipant[]>();

// 2. Error Handler with FirestoreInfo standard
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {},
    operationType,
    path
  };
  console.error('[FIRESTORE EXCEPTION]', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test Firebase Connection at start
async function testConnection() {
  if (usingMockDb) {
    console.log("[FIREBASE] Running in-memory store mode. Firebase Firestore connection checks bypassed.");
    return;
  }
  try {
    await getDocFromServer(doc(firestoreDb, 'test', 'connection'));
    console.log("[FIREBASE] Connection to Firestore established successfully.");
  } catch (error: any) {
    const errMsg = error instanceof Error ? error.message : String(error);
    console.warn("[FIREBASE] Connection failed:", errMsg);
    
    // Automatically fallback to in-memory mock if database not found, region/resource mismatch or blocked
    if (
      errMsg.includes("NOT_FOUND") || 
      errMsg.includes("not found") || 
      errMsg.includes("database") || 
      errMsg.includes("5") || 
      errMsg.includes("permission")
    ) {
      console.warn("[FIREBASE] Firestore Database is not provisioned or could not be found. Automatically falling back to in-memory mock database to allow local execution of the application.");
      usingMockDb = true;
    }
  }
}

// 3. Firestore DB Access Helpers
async function getAllUsers(): Promise<DBUser[]> {
  if (usingMockDb) {
    return localUsers;
  }
  const colPath = "users";
  try {
    const qSnapshot = await getDocs(collection(firestoreDb, colPath));
    const list: DBUser[] = [];
    qSnapshot.forEach((doc) => {
      list.push(doc.data() as DBUser);
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, colPath);
    return [];
  }
}

async function getUser(username: string): Promise<DBUser | null> {
  const tUsername = username.toLowerCase();
  if (usingMockDb) {
    return localUsers.find(u => u.username.toLowerCase() === tUsername) || null;
  }
  const docPath = `users/${tUsername}`;
  try {
    const dSnapshot = await getDoc(doc(firestoreDb, "users", tUsername));
    if (dSnapshot.exists()) {
      return dSnapshot.data() as DBUser;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, docPath);
    return null;
  }
}

async function saveUser(user: DBUser): Promise<void> {
  const tUsername = user.username.toLowerCase();
  if (usingMockDb) {
    const idx = localUsers.findIndex(u => u.username.toLowerCase() === tUsername);
    if (idx > -1) {
      localUsers[idx] = user;
    } else {
      localUsers.push(user);
    }
    return;
  }
  const docPath = `users/${tUsername}`;
  try {
    await setDoc(doc(firestoreDb, "users", tUsername), user);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

async function getPrivateMessages(userA: string, userB: string): Promise<DBPrivateMessage[]> {
  const uA = userA.toLowerCase();
  const uB = userB.toLowerCase();
  if (usingMockDb) {
    return localPrivateMessages.filter(
      m => (m.from.toLowerCase() === uA && m.to.toLowerCase() === uB) ||
           (m.from.toLowerCase() === uB && m.to.toLowerCase() === uA)
    );
  }
  const colPath = "privateMessages";
  try {
    const qSnapshot = await getDocs(collection(firestoreDb, colPath));
    const list: DBPrivateMessage[] = [];
    qSnapshot.forEach((doc) => {
      list.push(doc.data() as DBPrivateMessage);
    });
    return list.filter(
      m => (m.from.toLowerCase() === uA && m.to.toLowerCase() === uB) ||
           (m.from.toLowerCase() === uB && m.to.toLowerCase() === uA)
    );
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, colPath);
    return [];
  }
}

async function savePrivateMessage(msg: DBPrivateMessage): Promise<void> {
  if (usingMockDb) {
    localPrivateMessages.push(msg);
    return;
  }
  const docPath = `privateMessages/${msg.id}`;
  try {
    await setDoc(doc(firestoreDb, "privateMessages", msg.id), msg);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

async function getAllCommunities(): Promise<DBCommunity[]> {
  if (usingMockDb) {
    return localCommunities;
  }
  const colPath = "communities";
  try {
    const qSnapshot = await getDocs(collection(firestoreDb, colPath));
    const list: DBCommunity[] = [];
    qSnapshot.forEach((doc) => {
      list.push(doc.data() as DBCommunity);
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, colPath);
    return [];
  }
}

async function getCommunity(id: string): Promise<DBCommunity | null> {
  if (usingMockDb) {
    return localCommunities.find(c => c.id === id) || null;
  }
  const docPath = `communities/${id}`;
  try {
    const dSnapshot = await getDoc(doc(firestoreDb, "communities", id));
    if (dSnapshot.exists()) {
      return dSnapshot.data() as DBCommunity;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, docPath);
    return null;
  }
}

async function saveCommunity(comm: DBCommunity): Promise<void> {
  if (usingMockDb) {
    const idx = localCommunities.findIndex(c => c.id === comm.id);
    if (idx > -1) {
      localCommunities[idx] = comm;
    } else {
      localCommunities.push(comm);
    }
    return;
  }
  const docPath = `communities/${comm.id}`;
  try {
    await setDoc(doc(firestoreDb, "communities", comm.id), comm);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

async function getCommunityMessages(communityId: string): Promise<DBCommunityMessage[]> {
  if (usingMockDb) {
    return localCommunityMessages.filter(m => m.communityId === communityId);
  }
  const colPath = "communityMessages";
  try {
    const qSnapshot = await getDocs(collection(firestoreDb, colPath));
    const list: DBCommunityMessage[] = [];
    qSnapshot.forEach((doc) => {
      const data = doc.data() as DBCommunityMessage;
      if (data.communityId === communityId) {
        list.push(data);
      }
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, colPath);
    return [];
  }
}

async function saveCommunityMessage(msg: DBCommunityMessage): Promise<void> {
  if (usingMockDb) {
    localCommunityMessages.push(msg);
    return;
  }
  const docPath = `communityMessages/${msg.id}`;
  try {
    await setDoc(doc(firestoreDb, "communityMessages", msg.id), msg);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

async function getVoiceStream(communityId: string): Promise<DBVoiceStreamParticipant[]> {
  if (usingMockDb) {
    return localVoiceStreams.get(communityId) || [];
  }
  const docPath = `voiceStreams/${communityId}`;
  try {
    const dSnapshot = await getDoc(doc(firestoreDb, "voiceStreams", communityId));
    if (dSnapshot.exists()) {
      const data = dSnapshot.data() as { communityId: string; participants: DBVoiceStreamParticipant[] };
      return data.participants || [];
    }
    return [];
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, docPath);
    return [];
  }
}

async function saveVoiceStream(communityId: string, participants: DBVoiceStreamParticipant[]): Promise<void> {
  if (usingMockDb) {
    localVoiceStreams.set(communityId, participants);
    return;
  }
  const docPath = `voiceStreams/${communityId}`;
  try {
    await setDoc(doc(firestoreDb, "voiceStreams", communityId), { communityId, participants });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

// 4. Base Bootstrap to populate Firestore initially so page is not empty and has a supreme admin
async function bootstrapFirestore() {
  // Always verify connection before starting the bootstrap
  await testConnection();
  
  console.log("[FIREBASE] Checking if Firestore has initial data structures... (Using Mock DB: " + usingMockDb + ")");
  try {
    const users = await getAllUsers();
    if (users.length === 0) {
      console.log("[FIREBASE] Populating Firestore with live Android app defaults...");
      
      const defaultUsers: DBUser[] = [
        {
          username: "admin",
          passwordHash: "ahmad199231",
          phone: "0500111222",
          avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=admin",
          status: "المطور والمالك الرئيسي للتطبيق 👑",
          points: 1000,
          isBanned: false,
          isModerator: true,
          createdAt: new Date().toISOString(),
          friends: ["سالم", "منى"]
        },
        {
          username: "سالم",
          passwordHash: "salem123",
          phone: "0551234567",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=salem",
          status: "محب للمحادثات والمجتمعات التقنية ☕",
          points: 25,
          isBanned: false,
          isModerator: false,
          createdAt: new Date().toISOString(),
          friends: ["admin", "منى", "رائد"]
        },
        {
          username: "منى",
          passwordHash: "mona123",
          phone: "0557654321",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=mona",
          status: "مشرفة ومصممة واجهات 🎨",
          points: 40,
          isBanned: false,
          isModerator: true,
          createdAt: new Date().toISOString(),
          friends: ["admin", "سالم"]
        },
        {
          username: "رائد",
          passwordHash: "raed123",
          phone: "0559990000",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=raed",
          status: "مستكشف جديد في تطبيق Friends!",
          points: 5,
          isBanned: false,
          isModerator: false,
          createdAt: new Date().toISOString(),
          friends: ["سالم"]
        }
      ];

      for (const u of defaultUsers) {
        await saveUser(u);
      }

      const defaultMessages: DBPrivateMessage[] = [
        {
          id: "msg1",
          from: "admin",
          to: "سالم",
          text: "أهلاً بك يا سالم في تطبيق Friends! يسعدنا انضمامك إلينا.",
          timestamp: new Date(Date.now() - 3600000 * 4).toISOString()
        },
        {
          id: "msg2",
          from: "سالم",
          to: "admin",
          text: "أهلاً بك يا حضرة المدير، التطبيق رائع ومنظم جداً أشكرك على الإبداع!",
          timestamp: new Date(Date.now() - 3600000 * 3.8).toISOString()
        },
        {
          id: "msg3",
          from: "منى",
          to: "سالم",
          text: "أهلاً سالم، هل قمت بتجربة إنشاء مجتمع جديد بالنقاط الخاصة بك؟",
          timestamp: new Date(Date.now() - 3600000 * 1.5).toISOString()
        }
      ];

      for (const m of defaultMessages) {
        await savePrivateMessage(m);
      }

      const defaultCommunities: DBCommunity[] = [
        {
          id: "tech-world",
          name: "عالم التقنية والبرمجة 📱",
          description: "مجتمع يجمع المطورين والمهتمين بجديد التكنولوجيا البرمجية.",
          owner: "منى",
          members: ["منى", "سالم", "admin"],
          admins: ["منى", "admin"],
          banList: [],
          joinRequests: ["رائد"],
          isBanned: false
        },
        {
          id: "coffee-club",
          name: "عشاق القهوة والقراءة ☕",
          description: "مساحة رائعة لمشاركة الكتب المفضلة والحديث عن أنواع البن.",
          owner: "سالم",
          members: ["سالم", "منى"],
          admins: ["سالم"],
          banList: [],
          joinRequests: [],
          isBanned: false
        }
      ];

      for (const c of defaultCommunities) {
        await saveCommunity(c);
      }

      const defaultCommMessages: DBCommunityMessage[] = [
        {
          id: "cmsg1",
          communityId: "tech-world",
          sender: "منى",
          text: "السلام عليكم جميعاً! تم إطلاق البث الصوتي الآن لمناقشة تحديثات React 19.",
          timestamp: new Date(Date.now() - 3600000 * 2).toISOString()
        },
        {
          id: "cmsg2",
          communityId: "tech-world",
          sender: "سالم",
          text: "وعليكم السلام! سأنضم حالاً للبث الصوتي، موضوع ممتاز جداً.",
          timestamp: new Date(Date.now() - 3600000 * 1.8).toISOString()
        }
      ];

      for (const cm of defaultCommMessages) {
        await saveCommunityMessage(cm);
      }

      const defaultVoiceStreams = {
        "tech-world": [
          { username: "منى", isSpeaking: true, isMuted: false, canSpeak: true },
          { username: "سالم", isSpeaking: false, isMuted: true, canSpeak: true }
        ]
      };

      for (const [k, v] of Object.entries(defaultVoiceStreams)) {
        await saveVoiceStream(k, v);
      }

      console.log("[FIREBASE] Bootstrapping fresh Firestore database completed.");
    } else {
      // Ensure absolute admin exists
      const admin = await getUser("admin");
      if (!admin) {
        await saveUser({
          username: "admin",
          passwordHash: "ahmad199231",
          phone: "0500111222",
          avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=admin",
          status: "المطور والمالك الرئيسي للتطبيق 👑",
          points: 1000,
          isBanned: false,
          isModerator: true,
          createdAt: new Date().toISOString(),
          friends: []
        });
      } else {
        // Enforce administrative safety options
        admin.passwordHash = "ahmad199231";
        admin.isModerator = true;
        admin.isBanned = false;
        await saveUser(admin);
      }
    }
  } catch (err) {
    console.error("[FIREBASE] Bootstrapping failed:", err);
  }
}

// Start Express Server and endpoints
async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Bootstrap data in background asynchronously so port 3000 binds instantly without any blocking or hangs
  bootstrapFirestore().catch(err => {
    console.error("[FIREBASE] Background bootstrap failed:", err);
  });

  // API: Health probe
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString(), engine: "firestore" });
  });

  // API: User Authentication & Registration
  app.post("/api/register", async (req, res) => {
    try {
      const { username, password, phone, avatar, status } = req.body;

      if (!username || !password || !phone) {
        return res.status(400).json({ error: "جميع الحقول (اسم المستخدم، كلمة المرور، رقم الهاتف) إجبارية!" });
      }

      const trimmedUsername = username.trim();
      if (trimmedUsername.toLowerCase() === "admin") {
        return res.status(400).json({ error: "لا يمكن التسجيل باسم admin لأنه حساب محمي!" });
      }

      const exists = await getUser(trimmedUsername);
      if (exists) {
        return res.status(400).json({ error: "اسم المستخدم هذا مسجل بالفعل!" });
      }

      const newUser: DBUser = {
        username: trimmedUsername,
        passwordHash: password,
        phone: phone.trim(),
        avatar: avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(trimmedUsername)}`,
        status: status || "عضو جديد في مجتمعات Friends ✨",
        points: 0,
        isBanned: false,
        isModerator: false,
        createdAt: new Date().toISOString(),
        friends: ["admin"]
      };

      // Autolink admin Bidirectional
      const adminInst = await getUser("admin");
      if (adminInst) {
        if (!adminInst.friends) adminInst.friends = [];
        if (!adminInst.friends.includes(trimmedUsername)) {
          adminInst.friends.push(trimmedUsername);
          await saveUser(adminInst);
        }
      }

      await saveUser(newUser);

      res.json({ 
        success: true, 
        user: { 
          username: newUser.username, 
          phone: newUser.phone, 
          avatar: newUser.avatar, 
          status: newUser.status, 
          points: newUser.points, 
          isBanned: newUser.isBanned, 
          isModerator: newUser.isModerator, 
          friends: newUser.friends 
        } 
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل تسجيل مستخدم جديد" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        return res.status(400).json({ error: "يرجى تحديد اسم المستخدم وكلمة المرور!" });
      }

      const user = await getUser(username.trim());
      if (!user) {
        return res.status(400).json({ error: "اسم المستخدم غير موجود!" });
      }

      if (user.passwordHash !== password) {
        return res.status(400).json({ error: "كلمة المرور غير صحيحة!" });
      }

      if (user.isBanned) {
        return res.status(403).json({ error: "تم حظر حسابك من قبل الإدارة!" });
      }

      res.json({
        success: true,
        user: {
          username: user.username,
          phone: user.phone,
          avatar: user.avatar,
          status: user.status,
          points: user.points,
          isBanned: user.isBanned,
          isModerator: user.isModerator,
          friends: user.friends || []
        }
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل الدخول للحساب" });
    }
  });

  // Account recovery using phone
  app.post("/api/recover", async (req, res) => {
    try {
      const { phone, username, newPassword } = req.body;

      if (!phone || !username || !newPassword) {
        return res.status(400).json({ error: "يرجى إدخال اسم المستخدم ورقم الهاتف وكلمة المرور الجديدة!" });
      }

      const user = await getUser(username.trim());
      if (!user || user.phone !== phone.trim()) {
        return res.status(400).json({ error: "لا يوجد مستخدم متطابق مع اسم المستخدم ورقم الهاتف المدخلين!" });
      }

      if (user.username.toLowerCase() === "admin") {
        return res.status(403).json({ error: "غير مسموح باسترجاع حساب الإدارة الرئيسي عبر الهاتف!" });
      }

      user.passwordHash = newPassword;
      await saveUser(user);

      res.json({ success: true, message: "تم تغيير واستعادة كلمة المرور بنجاح!" });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشلت الاستعادة" });
    }
  });

  // Update profile
  app.post("/api/update-profile", async (req, res) => {
    try {
      const { username, avatar, status, phone, password } = req.body;

      const user = await getUser(username.trim());
      if (!user) {
        return res.status(404).json({ error: "العضو غير موجود!" });
      }

      if (avatar) user.avatar = avatar;
      if (status !== undefined) user.status = status;
      if (phone) user.phone = phone.trim();
      if (password) {
        if (user.username.toLowerCase() === "admin") {
          return res.status(403).json({ error: "لا يمكن تعديل كلمة مرور المالك الرئيسي من الإعدادات العامة!" });
        }
        user.passwordHash = password;
      }

      await saveUser(user);

      res.json({
        success: true,
        user: {
          username: user.username,
          phone: user.phone,
          avatar: user.avatar,
          status: user.status,
          points: user.points,
          isBanned: user.isBanned,
          isModerator: user.isModerator,
          friends: user.friends || []
        }
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل التعديل" });
    }
  });

  // Get active users lists
  app.get("/api/users", async (req, res) => {
    try {
      const users = await getAllUsers();
      const basicUsers = users.map(u => ({
        username: u.username,
        avatar: u.avatar,
        status: u.status,
        points: u.points,
        isBanned: u.isBanned,
        isModerator: u.isModerator,
        createdAt: u.createdAt
      }));
      res.json(basicUsers);
    } catch (e: any) {
      res.status(500).json([]);
    }
  });

  app.get("/api/user/:username", async (req, res) => {
    try {
      const user = await getUser(req.params.username);
      if (!user) {
        return res.status(404).json({ error: "المستخدم غير موجود!" });
      }
      res.json({
        username: user.username,
        avatar: user.avatar,
        status: user.status,
        points: user.points,
        isBanned: user.isBanned,
        isModerator: user.isModerator,
        createdAt: user.createdAt,
        friends: user.friends || []
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل جلب المستخدم" });
    }
  });

  // Toggle Friend
  app.post("/api/friends/toggle", async (req, res) => {
    try {
      const { username, targetFriend } = req.body;

      const user = await getUser(username);
      const friendObj = await getUser(targetFriend);

      if (!user || !friendObj) {
        return res.status(404).json({ error: "المستخدم غير موجود!" });
      }

      if (!user.friends) user.friends = [];
      if (!friendObj.friends) friendObj.friends = [];

      const index = user.friends.indexOf(friendObj.username);
      if (index > -1) {
        user.friends.splice(index, 1);
        const indexBack = friendObj.friends.indexOf(user.username);
        if (indexBack > -1) {
          friendObj.friends.splice(indexBack, 1);
        }
      } else {
        user.friends.push(friendObj.username);
        if (!friendObj.friends.includes(user.username)) {
          friendObj.friends.push(user.username);
        }
      }

      await saveUser(user);
      await saveUser(friendObj);

      res.json({ success: true, friends: user.friends });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشلت كسر الصداقة" });
    }
  });

  // API : Get and post private messages
  app.get("/api/messages/:userA/:userB", async (req, res) => {
    try {
      const chats = await getPrivateMessages(req.params.userA, req.params.userB);
      res.json(chats);
    } catch (e) {
      res.json([]);
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const { from, to, text } = req.body;

      if (!from || !to || !text) {
        return res.status(400).json({ error: "برجاء توفير كل من المرسل والمستقبل ونص الرسالة!" });
      }

      const sender = await getUser(from);
      if (sender?.isBanned) {
        return res.status(403).json({ error: "أنت محظور من استخدام الشات!" });
      }

      const newMsg: DBPrivateMessage = {
        id: "msg_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
        from,
        to,
        text,
        timestamp: new Date().toISOString()
      };

      await savePrivateMessage(newMsg);
      
      // Keep contacts updated
      if (sender) {
        if (!sender.friends) sender.friends = [];
        if (!sender.friends.includes(to)) {
          sender.friends.push(to);
          await saveUser(sender);
        }
      }

      const receiver = await getUser(to);
      if (receiver) {
        if (!receiver.friends) receiver.friends = [];
        if (!receiver.friends.includes(from)) {
          receiver.friends.push(from);
          await saveUser(receiver);
        }
      }

      res.json(newMsg);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل إرسال الرسالة" });
    }
  });

  // API: Communities Management
  app.get("/api/communities", async (req, res) => {
    try {
      const comms = await getAllCommunities();
      res.json(comms);
    } catch (e) {
      res.json([]);
    }
  });

  app.post("/api/communities/create", async (req, res) => {
    try {
      const { name, description, owner } = req.body;

      if (!name || !owner) {
        return res.status(400).json({ error: "اسم المجتمع وصاحب المجتمع مطلوبين!" });
      }

      const ownerUser = await getUser(owner);
      if (!ownerUser) {
        return res.status(404).json({ error: "المالك المذكور غير موجود!" });
      }

      if (ownerUser.isBanned) {
        return res.status(403).json({ error: "صاحب الحساب محظور ولا يمكنه تفعيل مجتمعات!" });
      }

      if (ownerUser.points < 10 && ownerUser.username.toLowerCase() !== "admin") {
        return res.status(400).json({ error: "ليس لديك نقاط كافية لإنشاء مجتمع! تحتاج لـ 10 نقاط على الأقل من مدير التطبيق." });
      }

      if (ownerUser.username.toLowerCase() !== "admin") {
        ownerUser.points -= 10;
        await saveUser(ownerUser);
      }

      const communityId = "comm_" + Date.now();

      const newComm: DBCommunity = {
        id: communityId,
        name: name.trim(),
        description: description || "لا يوجد وصف متوفر لهذا المجتمع بعد.",
        owner: ownerUser.username,
        members: [ownerUser.username],
        admins: [ownerUser.username],
        banList: [],
        joinRequests: [],
        isBanned: false
      };

      await saveCommunity(newComm);

      res.json({ success: true, community: newComm, pointsRemaining: ownerUser.points });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "عذراً تعذر تفعيل المجتمع" });
    }
  });

  app.post("/api/communities/join-request", async (req, res) => {
    try {
      const { communityId, username } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      if (comm.banList.includes(username)) {
        return res.status(403).json({ error: "أنت محظور من الانضمام لهذا المجتمع!" });
      }

      if (comm.members.includes(username)) {
        return res.status(400).json({ error: "أنت عضو بالفعل في هذا المجتمع!" });
      }

      if (comm.joinRequests.includes(username)) {
        return res.status(400).json({ error: "لقد أرسلت طلب انضمام مسبقاً وهو قيد المراجعة!" });
      }

      comm.joinRequests.push(username);
      await saveCommunity(comm);

      res.json({ success: true, message: "تم إرسال طلب الانضمام لمالكي المجتمع بنجاح." });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل إرسال طلب الانضمام" });
    }
  });

  app.post("/api/communities/manage-request", async (req, res) => {
    try {
      const { communityId, requester, action, actor } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      const isActorAuthorized = comm.admins.includes(actor) || comm.owner === actor;
      if (!isActorAuthorized) {
        return res.status(403).json({ error: "ليس لديك صلاحية لإدارة طلبات الانضمام!" });
      }

      comm.joinRequests = comm.joinRequests.filter(r => r !== requester);

      if (action === "approve") {
        if (!comm.members.includes(requester)) {
          comm.members.push(requester);
        }
      }

      await saveCommunity(comm);
      res.json({ success: true, community: comm });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل التحكم" });
    }
  });

  // Kick / ban from inside community
  app.post("/api/communities/kick", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      const isAdmin = comm.admins.includes(actor) || comm.owner === actor;
      if (!isAdmin) return res.status(403).json({ error: "غير مصرح لك!" });

      if (target === comm.owner) {
        return res.status(403).json({ error: "لا يمكن إزالة مالك المجتمع الأصلي!" });
      }

      if (comm.admins.includes(target) && actor !== comm.owner) {
        return res.status(403).json({ error: "بصفتك مشرفاً، لا يمكنك طرد مشرف آخر! فقط المالك يمكنه ذلك." });
      }

      comm.members = comm.members.filter(m => m !== target);
      comm.admins = comm.admins.filter(m => m !== target);

      // Save Com
      await saveCommunity(comm);

      // Clean voice stream
      const vs = await getVoiceStream(communityId);
      const vsFilter = vs.filter(p => p.username !== target);
      await saveVoiceStream(communityId, vsFilter);

      res.json({ success: true, community: comm });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل الطرد" });
    }
  });

  app.post("/api/communities/ban-member", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      const isAdmin = comm.admins.includes(actor) || comm.owner === actor;
      if (!isAdmin) return res.status(403).json({ error: "غير مصرح لك!" });

      if (target === comm.owner) {
        return res.status(403).json({ error: "لا يمكن حظر منشئ ومالك المجتمع الأصلي!" });
      }

      if (comm.admins.includes(target) && actor !== comm.owner) {
        return res.status(403).json({ error: "المشرف لا يستطيع حظر مشرفاً آخر. فقط منشئ الغرفة يستطيع ذلك." });
      }

      comm.members = comm.members.filter(m => m !== target);
      comm.admins = comm.admins.filter(m => m !== target);
      if (!comm.banList.includes(target)) {
        comm.banList.push(target);
      }

      await saveCommunity(comm);

      // Clean voice
      const vs = await getVoiceStream(communityId);
      const vsFilter = vs.filter(p => p.username !== target);
      await saveVoiceStream(communityId, vsFilter);

      res.json({ success: true, community: comm });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فصل الحظر" });
    }
  });

  // Promote Member to admin
  app.post("/api/communities/promote", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      if (comm.owner !== actor) {
        return res.status(403).json({ error: "فقط صاحب الغرفة الرئيسي يستطيع تعيين مشرفين (أدمن)!" });
      }

      if (!comm.members.includes(target)) {
        return res.status(400).json({ error: "المستخدم المرشح ليس عضواً في المجتمع!" });
      }

      if (!comm.admins.includes(target)) {
        comm.admins.push(target);
      }

      await saveCommunity(comm);
      res.json({ success: true, community: comm });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل الترقية" });
    }
  });

  // Demote Admin to normal member
  app.post("/api/communities/demote", async (req, res) => {
    try {
      const { communityId, target, actor } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      if (comm.owner !== actor) {
        return res.status(403).json({ error: "فقط صاحب الغرفة الرئيسي يستطيع إزالة مشرفين!" });
      }

      if (target === comm.owner) {
        return res.status(400).json({ error: "لا يمكن تعديل رتبة منشئ الغرفة الأصلي!" });
      }

      comm.admins = comm.admins.filter(a => a !== target);

      await saveCommunity(comm);
      res.json({ success: true, community: comm });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشلت عملية العزل" });
    }
  });

  // Leave community
  app.post("/api/communities/leave", async (req, res) => {
    try {
      const { communityId, username } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      if (comm.owner === username) {
        return res.status(400).json({ error: "لا يمكن لمالك المجتمع مغادرته نهائياً! يمكنك حذفه تماماً عبر الدعم." });
      }

      comm.members = comm.members.filter(m => m !== username);
      comm.admins = comm.admins.filter(m => m !== username);

      await saveCommunity(comm);

      // Clean voice
      const vs = await getVoiceStream(communityId);
      const vsFilter = vs.filter(p => p.username !== username);
      await saveVoiceStream(communityId, vsFilter);

      res.json({ success: true, community: comm });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل الخروج" });
    }
  });

  // Community Content Messages
  app.get("/api/communities/:communityId/messages", async (req, res) => {
    try {
      const msgs = await getCommunityMessages(req.params.communityId);
      res.json(msgs);
    } catch (e) {
      res.json([]);
    }
  });

  app.post("/api/communities/messages", async (req, res) => {
    try {
      const { communityId, sender, text } = req.body;

      if (!communityId || !sender || !text) {
        return res.status(400).json({ error: "تأكد من توفير رقم المجتمع، المرسل، ونص الرسالة!" });
      }

      const userObj = await getUser(sender);
      if (userObj?.isBanned) {
        return res.status(403).json({ error: "أنت محظور من المشاركة وإرسال الرسائل!" });
      }

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع لم يعد موجوداً!" });

      if (!comm.members.includes(sender)) {
        return res.status(403).json({ error: "يجب أن تنضم للمجتمع أولاً لتتمكن من إرسال الرسائل!" });
      }

      const newMsg: DBCommunityMessage = {
        id: "cm_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
        communityId,
        sender,
        text,
        timestamp: new Date().toISOString()
      };

      await saveCommunityMessage(newMsg);

      res.json(newMsg);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل مشاركة الرسالة" });
    }
  });

  // VOICE STREAM STATE & CONTROL SIMULATOR
  app.get("/api/voice-stream/:communityId", async (req, res) => {
    try {
      const communityId = req.params.communityId;
      const participants = await getVoiceStream(communityId);
      res.json({ communityId, participants });
    } catch (e) {
      res.json({ communityId: req.params.communityId, participants: [] });
    }
  });

  app.post("/api/voice-stream/join", async (req, res) => {
    try {
      const { communityId, username } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      if (!comm.members.includes(username)) {
        return res.status(403).json({ error: "يجب أن تكون عضواً في المجتمع لتنضم للبث الصوتي!" });
      }

      const stream = await getVoiceStream(communityId);

      const existingIdx = stream.findIndex(p => p.username === username);
      if (existingIdx === -1) {
        stream.push({
          username,
          isSpeaking: false,
          isMuted: false,
          canSpeak: true
        });
        await saveVoiceStream(communityId, stream);
      }

      res.json({ success: true, participants: stream });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "تعذر الانضمام للبث" });
    }
  });

  app.post("/api/voice-stream/leave", async (req, res) => {
    try {
      const { communityId, username } = req.body;

      const stream = await getVoiceStream(communityId);
      const filtered = stream.filter(p => p.username !== username);
      await saveVoiceStream(communityId, filtered);

      res.json({ success: true, participants: filtered });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "تعذر ترك البث" });
    }
  });

  app.post("/api/voice-stream/toggle-mute", async (req, res) => {
    try {
      const { communityId, username, isMuted } = req.body;

      const stream = await getVoiceStream(communityId);
      const participant = stream.find(p => p.username === username);
      if (participant) {
        participant.isMuted = isMuted;
        if (isMuted) {
          participant.isSpeaking = false;
        }
        await saveVoiceStream(communityId, stream);
      }

      res.json({ success: true, participants: stream });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "خطأ كتم الصوت" });
    }
  });

  app.post("/api/voice-stream/simulate-speaking", async (req, res) => {
    try {
      const { communityId, username, isSpeaking } = req.body;

      const stream = await getVoiceStream(communityId);
      const participant = stream.find(p => p.username === username);
      if (participant) {
        if (!participant.isMuted && participant.canSpeak) {
          participant.isSpeaking = isSpeaking;
        } else {
          participant.isSpeaking = false;
        }
        await saveVoiceStream(communityId, stream);
      }

      res.json({ success: true, participants: stream });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/voice-stream/control", async (req, res) => {
    try {
      const { communityId, target, action, actor } = req.body;

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود!" });

      const isOwnerOrAdmin = comm.owner === actor || comm.admins.includes(actor);
      if (!isOwnerOrAdmin) {
        return res.status(403).json({ error: "صلاحية البث الصوتي متاحة للمالك والمشرفين فقط!" });
      }

      if (target === comm.owner && actor !== comm.owner) {
        return res.status(403).json({ error: "لا يمكن اتخاذ إجراء صوتي بحق مالك الغرفة الأصلي!" });
      }

      const stream = await getVoiceStream(communityId);
      let nextStream = [...stream];

      const participant = nextStream.find(p => p.username === target);
      if (participant) {
        switch (action) {
          case "mute":
            participant.isMuted = true;
            participant.isSpeaking = false;
            break;
          case "unmute":
            participant.isMuted = false;
            break;
          case "allow":
            participant.canSpeak = true;
            break;
          case "block":
            participant.canSpeak = false;
            participant.isSpeaking = false;
            participant.isMuted = true;
            break;
          case "kick":
            nextStream = nextStream.filter(p => p.username !== target);
            break;
        }
        await saveVoiceStream(communityId, nextStream);
      }

      res.json({ success: true, participants: nextStream });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشل التحكم بالصوت" });
    }
  });

  // ADMIN CONTROL PANEL ENDPOINTS
  app.post("/api/admin/grant-points", async (req, res) => {
    try {
      const { targetUsername, pointsAmount, actorAdmin } = req.body;

      const actor = await getUser(actorAdmin);
      if (!actor) {
        return res.status(403).json({ error: "المسؤول غير متواجد على قاعدة البيانات." });
      }

      const isOriginalAdmin = actor.username.toLowerCase() === "admin";
      if (!isOriginalAdmin && !actor.isModerator) {
        return res.status(403).json({ error: "ليس لديك صلاحية لوحة الإدارة!" });
      }

      const amt = parseInt(pointsAmount, 10);
      if (isNaN(amt) || amt <= 0) {
        return res.status(400).json({ error: "يرجى تحديد كمية نقاط صحيحة!" });
      }

      const targetUser = await getUser(targetUsername);
      if (!targetUser) {
        return res.status(404).json({ error: "المستهدف غير موجود لترقية نقاطه!" });
      }

      targetUser.points += amt;
      await saveUser(targetUser);

      res.json({ success: true, targetUser: { username: targetUser.username, points: targetUser.points } });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشلت العملية" });
    }
  });

  app.post("/api/admin/toggle-user-ban", async (req, res) => {
    try {
      const { targetUsername, isBanned, actorAdmin } = req.body;

      const actor = await getUser(actorAdmin);
      if (!actor || (!actor.isModerator && actor.username.toLowerCase() !== "admin")) {
        return res.status(403).json({ error: "ليس لديك صلاحيات لهذا الإجراء!" });
      }

      if (targetUsername.toLowerCase() === "admin") {
        return res.status(403).json({ error: "لا يمكن حظر حساب المالك الرئيسي (admin)!" });
      }

      const targetUser = await getUser(targetUsername);
      if (!targetUser) {
        return res.status(404).json({ error: "المستهدف غير موجود!" });
      }

      if (targetUser.isModerator && actor.username.toLowerCase() !== "admin") {
        return res.status(403).json({ error: "المشرفون لا يمكنهم حظر مشرفين آخرين للموقع. المالك فقط يستطيع ذلك!" });
      }

      targetUser.isBanned = isBanned;
      await saveUser(targetUser);

      res.json({ success: true, username: targetUser.username, isBanned: targetUser.isBanned });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشلت عملية الحظر" });
    }
  });

  app.post("/api/admin/toggle-community-ban", async (req, res) => {
    try {
      const { communityId, isBanned, actorAdmin } = req.body;

      const actor = await getUser(actorAdmin);
      if (!actor || (!actor.isModerator && actor.username.toLowerCase() !== "admin")) {
        return res.status(403).json({ error: "ليس لديك صلاحيات لهذا الإجراء!" });
      }

      const comm = await getCommunity(communityId);
      if (!comm) return res.status(404).json({ error: "المجتمع غير موجود على الخادم!" });

      comm.isBanned = isBanned;
      await saveCommunity(comm);

      res.json({ success: true, communityId, isBanned });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشلت العملية" });
    }
  });

  app.post("/api/admin/manage-moderator", async (req, res) => {
    try {
      const { targetUsername, isModerator, actorAdmin } = req.body;

      if (actorAdmin.toLowerCase() !== "admin") {
        return res.status(403).json({ error: "فقط حساب الإدارة الرئيسي والمالك الأصلي (admin) يستطيع تعيين/عزل مسؤول عام للموقع!" });
      }

      const targetUser = await getUser(targetUsername);
      if (!targetUser) {
        return res.status(404).json({ error: "المستخدم المعني بطلب الإدارة غير موجود!" });
      }

      if (targetUser.username.toLowerCase() === "admin") {
        return res.status(400).json({ error: "المطور والمالك الرئيسي ليس بحاجة لتعيين أو تعديل صلاحيات!" });
      }

      targetUser.isModerator = isModerator;
      await saveUser(targetUser);

      res.json({ success: true, username: targetUser.username, isModerator: targetUser.isModerator });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "فشلت العملية" });
    }
  });

  app.post("/api/voice-stream/ping", (req, res) => {
    res.json({ success: true });
  });

  // Serve Frontend assets nicely
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[FRIENDS SERVER] Live Android server running on http://localhost:${PORT}`);
  });
}

startServer();
