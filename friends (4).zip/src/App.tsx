/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Users, Hash, MessageSquare, ShieldAlert, Award, Volume2, 
  VolumeX, Settings, LogOut, Send, Plus, Check, X, Shield, 
  UserPlus, UserMinus, Mic, MicOff, Star, AlertTriangle, 
  UserCheck, Smartphone, Key, Image, Trash2, ShieldCheck, HelpCircle,
  ArrowRight
} from "lucide-react";
import AuthScreen from "./components/AuthScreen";
import { getApiUrl } from "./apiConfig";
import { User, Community, PrivateMessage, CommunityMessage, VoiceStreamState } from "./types";

// Override fetch on file level to prepend backend API URLs automatically in Capacitor / android APKs
const fetch = (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
  if (typeof input === "string") {
    return window.fetch(getApiUrl(input), init);
  }
  return window.fetch(input, init);
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [sessionLoading, setSessionLoading] = useState(true);

  // Android Simulator Configurations
  const [deviceModel, setDeviceModel] = useState<"phone" | "tablet" | "fullscreen">("phone");
  const [androidTime, setAndroidTime] = useState("");
  useEffect(() => {
    const calcTime = () => {
      const now = new Date();
      let hr = now.getHours();
      const min = now.getMinutes().toString().padStart(2, '0');
      const amp = hr >= 12 ? 'م' : 'ص';
      hr = hr % 12 || 12;
      setAndroidTime(`${hr}:${min} ${amp}`);
    };
    calcTime();
    const t = setInterval(calcTime, 10000);
    return () => clearInterval(t);
  }, []);

  // App Master Lists
  const [usersList, setUsersList] = useState<User[]>([]);
  const [communitiesList, setCommunitiesList] = useState<Community[]>([]);
  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null);
  const [communityMessages, setCommunityMessages] = useState<CommunityMessage[]>([]);
  const [selectedFriendUsername, setSelectedFriendUsername] = useState<string | null>(null);
  const [privateMessages, setPrivateMessages] = useState<PrivateMessage[]>([]);
  
  // Tabs Navigation
  const [activeSubTab, setActiveSubTab] = useState<"communities" | "friends" | "profile" | "admin">("communities");

  // Voice stream status
  const [activeVoiceStream, setActiveVoiceStream] = useState<{
    communityId: string;
    participants: { username: string; isSpeaking: boolean; isMuted: boolean; canSpeak: boolean }[];
  } | null>(null);
  const [isSelfVoiceMuted, setIsSelfVoiceMuted] = useState(false);

  // Modals & Creation States
  const [showCreateCommunity, setShowCreateCommunity] = useState(false);
  const [newCommunityName, setNewCommunityName] = useState("");
  const [newCommunityDesc, setNewCommunityDesc] = useState("");

  // Search filter
  const [searchQuery, setSearchQuery] = useState("");

  // Input message box
  const [messageText, setMessageText] = useState("");

  // Settings Edit states
  const [editAvatar, setEditAvatar] = useState("");
  const [editStatus, setEditStatus] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editPassword, setEditPassword] = useState("");
  const [settingsSuccess, setSettingsSuccess] = useState("");
  const [settingsError, setSettingsError] = useState("");

  // Admin secret entry
  const [adminPasscode, setAdminPasscode] = useState("");
  const [isAdminPanelUnlocked, setIsAdminPanelUnlocked] = useState(false);
  const [adminGrantTarget, setAdminGrantTarget] = useState("");
  const [adminGrantPoints, setAdminGrantPoints] = useState("10");
  const [adminSuccess, setAdminSuccess] = useState("");
  const [adminError, setAdminError] = useState("");

  // Messages Scroll Ref
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Check login session on load
  useEffect(() => {
    const saved = localStorage.getItem("friends_user");
    if (saved) {
      try {
        const u = JSON.parse(saved) as User;
        setCurrentUser(u);
      } catch (e) {
        localStorage.removeItem("friends_user");
      }
    }
    setSessionLoading(false);
  }, []);

  // Fetch critical core data regularly (Poller to keep it ultra real-time without socket complexity)
  useEffect(() => {
    if (!currentUser) return;

    const fetchData = async () => {
      try {
        // 1. Fetch Users List
        const resUsers = await fetch("/api/users");
        if (resUsers.ok) {
          const list = await resUsers.json();
          setUsersList(list);
          
          // Sync current logged user in case of admin points change or ban
          const freshSelf = list.find((u: any) => u.username.toLowerCase() === currentUser.username.toLowerCase());
          if (freshSelf) {
            if (freshSelf.isBanned) {
              alert("تم حضر حسابك من قبل الإدارة!");
              handleLogout();
              return;
            }
            // Keep points and status updated state
            setCurrentUser(prev => prev ? { 
              ...prev, 
              points: freshSelf.points, 
              isModerator: freshSelf.isModerator, 
              phone: freshSelf.phone,
              avatar: freshSelf.avatar,
              status: freshSelf.status
            } : null);
          }
        }

        // 2. Fetch Communities List
        const resComm = await fetch("/api/communities");
        if (resComm.ok) {
          const comms = await resComm.json();
          setCommunitiesList(comms);
          
          // Sync currently select status community
          if (selectedCommunity) {
            const freshComm = comms.find((c: any) => c.id === selectedCommunity.id);
            if (freshComm) {
              if (freshComm.isBanned) {
                setSelectedCommunity(null);
                setCommunityMessages([]);
              } else {
                setSelectedCommunity(freshComm);
              }
            } else {
              setSelectedCommunity(null);
            }
          }
        }

        // 3. Fetch Voice Stream state if connected
        if (activeVoiceStream) {
          const resVoice = await fetch(`/api/voice-stream/${activeVoiceStream.communityId}`);
          if (resVoice.ok) {
            const voiceData = await resVoice.json();
            setActiveVoiceStream(voiceData);
          }
        }

      } catch (err) {
        console.error("Poller error:", err);
      }
    };

    fetchData(); // run once immediately
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, [currentUser, selectedCommunity?.id, activeVoiceStream?.communityId]);

  // Fetch messages when community or friend chat changes
  useEffect(() => {
    if (!currentUser) return;

    const fetchChatMessages = async () => {
      try {
        if (selectedCommunity) {
          const res = await fetch(`/api/communities/${selectedCommunity.id}/messages`);
          if (res.ok) {
            const chatList = await res.json();
            setCommunityMessages(chatList);
          }
        } else if (selectedFriendUsername) {
          const res = await fetch(`/api/messages/${currentUser.username}/${selectedFriendUsername}`);
          if (res.ok) {
            const chatList = await res.json();
            setPrivateMessages(chatList);
          }
        }
      } catch (err) {
        console.error("Fetch message error:", err);
      }
    };

    fetchChatMessages();
    const interval = setInterval(fetchChatMessages, 3500);
    return () => clearInterval(interval);
  }, [selectedCommunity?.id, selectedFriendUsername, currentUser?.username]);

  // Scroll to bottom helper
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [communityMessages, privateMessages, selectedCommunity, selectedFriendUsername]);

  // Handle Logout
  const handleLogout = () => {
    localStorage.removeItem("friends_user");
    setCurrentUser(null);
    setSelectedCommunity(null);
    setSelectedFriendUsername(null);
    setActiveVoiceStream(null);
  };

  // Profile Settings prefill
  useEffect(() => {
    if (currentUser) {
      setEditAvatar(currentUser.avatar || "");
      setEditStatus(currentUser.status || "");
      setEditPhone(currentUser.phone || "");
    }
  }, [currentUser?.username]);

  // Update Profile on DB
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsError("");
    setSettingsSuccess("");

    if (!currentUser) return;

    try {
      const res = await fetch("/api/update-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: currentUser.username,
          avatar: editAvatar.trim(),
          status: editStatus.trim(),
          phone: editPhone.trim(),
          password: editPassword ? editPassword : undefined
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "خطأ في تعديل الملف");
      }

      setCurrentUser(data.user);
      localStorage.setItem("friends_user", JSON.stringify(data.user));
      setSettingsSuccess("تم تحديث الملف الشخصي وتغيير الإعدادات بنجاح! ✨");
      setEditPassword("");
    } catch (err: any) {
      setSettingsError(err.message || "فشلت عملية حفظ التغييرات.");
    }
  };

  // Create Community Action
  const handleCreateCommunity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!newCommunityName.trim()) {
      alert("الرجاء ذكر اسم مميز للمجتمع!");
      return;
    }

    try {
      const res = await fetch("/api/communities/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newCommunityName.trim(),
          description: newCommunityDesc.trim(),
          owner: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "خطأ في إنشاء المجتمع");
      }

      // Update self balance of points
      setCurrentUser(prev => prev ? { ...prev, points: data.pointsRemaining } : null);
      
      // Auto elect community
      setSelectedCommunity(data.community);
      setNewCommunityName("");
      setNewCommunityDesc("");
      setShowCreateCommunity(false);
      setActiveSubTab("communities");
      
      // Refresh list
      const resComm = await fetch("/api/communities");
      if (resComm.ok) {
        setCommunitiesList(await resComm.json());
      }
    } catch (err: any) {
      alert(err.message || "عذراً تعذر تفعيل المجتمع بالنقاط.");
    }
  };

  // Join Community Request Send
  const handleSendJoinRequest = async (commId: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/communities/join-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: commId,
          username: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error);
      }

      alert("تم إرسال طلب الانضمام لمالكي وإدارة المجتمع! الرجاء انتظار الموافقة 🕊️");
      
      // Refresh
      const resComm = await fetch("/api/communities");
      if (resComm.ok) setCommunitiesList(await resComm.json());

    } catch (err: any) {
      alert(err.message || "تعذر إرسال الطلب.");
    }
  };

  // Accept / Refuse request
  const handleModerateRequest = async (communityId: string, requester: string, action: "approve" | "refuse") => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/communities/manage-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId,
          requester,
          action,
          actor: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setSelectedCommunity(data.community);
      
      // Refresh list
      const resComm = await fetch("/api/communities");
      if (resComm.ok) setCommunitiesList(await resComm.json());

    } catch (err: any) {
      alert(err.message);
    }
  };

  // Send Message Action (Community or Private Friend Chat)
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !currentUser) return;

    try {
      if (selectedCommunity) {
        const res = await fetch("/api/communities/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            communityId: selectedCommunity.id,
            sender: currentUser.username,
            text: messageText.trim()
          })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error);

        setCommunityMessages(prev => [...prev, data]);
        setMessageText("");

      } else if (selectedFriendUsername) {
        const res = await fetch("/api/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            from: currentUser.username,
            to: selectedFriendUsername,
            text: messageText.trim()
          })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error);

        setPrivateMessages(prev => [...prev, data]);
        setMessageText("");
      }
    } catch (err: any) {
      alert(err.message || "تعذر إرسال رسالتك");
    }
  };

  // Leave Community Action
  const handleLeaveCommunity = async (commId: string) => {
    if (!currentUser) return;
    if (!confirm("هل أنت متأكد من رغبتك في مغادرة هذا المجتمع؟")) return;

    try {
      const res = await fetch("/api/communities/leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: commId,
          username: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setSelectedCommunity(null);
      setCommunityMessages([]);
      
      // Refresh list
      const resComm = await fetch("/api/communities");
      if (resComm.ok) setCommunitiesList(await resComm.json());

      alert("تمت مغادرة المجتمع بنجاح.");
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Kick member from Community
  const handleKickMember = async (targetUser: string) => {
    if (!selectedCommunity || !currentUser) return;
    if (!confirm(`هل تريد بالتأكيد إزالة ${targetUser} من المجتمع؟`)) return;

    try {
      const res = await fetch("/api/communities/kick", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: selectedCommunity.id,
          target: targetUser,
          actor: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setSelectedCommunity(data.community);
      alert("تمت إزالة العضو من هذا المجتمع.");
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Ban member from Community
  const handleBanMember = async (targetUser: string) => {
    if (!selectedCommunity || !currentUser) return;
    if (!confirm(`هل تريد حظر ${targetUser} تماماً من الانضمام لهذا المجتمع؟`)) return;

    try {
      const res = await fetch("/api/communities/ban-member", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: selectedCommunity.id,
          target: targetUser,
          actor: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setSelectedCommunity(data.community);
      alert("تم حظر العضو ورقم معرفه من المجتمع نهائياً.");
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Toggle dynamic moderator/admin of Community
  const handleConfigureCommunityAdmin = async (targetUser: string, action: "promote" | "demote") => {
    if (!selectedCommunity || !currentUser) return;
    const url = action === "promote" ? "/api/communities/promote" : "/api/communities/demote";
    const statusMsg = action === "promote" ? "مشرفاً (أدمن)" : "عضواً عادياً";

    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: selectedCommunity.id,
          target: targetUser,
          actor: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setSelectedCommunity(data.community);
      alert(`تم تعديل الصلاحية، ${targetUser} الآن هو ${statusMsg}.`);
    } catch (err: any) {
      alert(err.message);
    }
  };

  // VOICE BROADCAST ACTIONS
  const handleJoinVoiceStream = async (commId: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/voice-stream/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: commId,
          username: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setActiveVoiceStream({
        communityId: commId,
        participants: data.participants
      });
      setIsSelfVoiceMuted(false);

    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleLeaveVoiceStream = async () => {
    if (!activeVoiceStream || !currentUser) return;
    try {
      await fetch("/api/voice-stream/leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: activeVoiceStream.communityId,
          username: currentUser.username
        })
      });
      setActiveVoiceStream(null);
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleSelfMuteInStream = async () => {
    if (!activeVoiceStream || !currentUser) return;
    const newVal = !isSelfVoiceMuted;
    try {
      const res = await fetch("/api/voice-stream/toggle-mute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: activeVoiceStream.communityId,
          username: currentUser.username,
          isMuted: newVal
        })
      });

      if (res.ok) {
        setIsSelfVoiceMuted(newVal);
        const data = await res.json();
        setActiveVoiceStream(prev => prev ? { ...prev, participants: data.participants } : null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Moderator / Admin sound options control
  const handleVoiceParticipantControl = async (target: string, action: "mute" | "unmute" | "allow" | "block" | "kick") => {
    if (!activeVoiceStream || !currentUser) return;
    try {
      const res = await fetch("/api/voice-stream/control", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: activeVoiceStream.communityId,
          target,
          action,
          actor: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setActiveVoiceStream(prev => prev ? { ...prev, participants: data.participants } : null);
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Simulate speaking trigger (makes user avatar glowing to indicate action)
  const handleSimulateSpeaking = async (isSpeaking: boolean) => {
    if (!activeVoiceStream || !currentUser || isSelfVoiceMuted) return;
    try {
      await fetch("/api/voice-stream/simulate-speaking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId: activeVoiceStream.communityId,
          username: currentUser.username,
          isSpeaking
        })
      });
    } catch (e) {
      // safe backdrop ignore
    }
  };

  // Toggle Friendly contact list
  const handleToggleFriendship = async (friendUser: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/friends/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: currentUser.username,
          targetFriend: friendUser
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      // update current user
      setCurrentUser(prev => prev ? { ...prev, friends: data.friends } : null);
      alert("تم تعديل حالة الصداقة لجهات اتصالك! يمكنك المحادثة معهم مجدداً.");
    } catch (err: any) {
      alert(err.message);
    }
  };

  // ADMIN OPERATIONS
  const handleValidatePasscode = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPasscode.trim() === "1911") {
      setIsAdminPanelUnlocked(true);
      setAdminSuccess("تم فحص الشفرة وإلغاء قفل لوحة التحكم بنجاح! للتحكم يرجى تسجيل الدخول بحساب مخول.");
      setAdminError("");
    } else {
      setIsAdminPanelUnlocked(false);
      setAdminError("الرمز السري المدخل غير صحيح! يرجى الاستعانة بالرمز الصحيح.");
      setAdminSuccess("");
    }
  };

  // Admin: Grant points
  const handleAdminGrantPoints = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminSuccess("");
    setAdminError("");

    if (!currentUser || !adminGrantTarget) {
      setAdminError("يرجى اختيار العضو وتحديد النقاط!");
      return;
    }

    try {
      const res = await fetch("/api/admin/grant-points", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetUsername: adminGrantTarget,
          pointsAmount: adminGrantPoints,
          actorAdmin: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setAdminSuccess(`تم منح ${adminGrantPoints} نقاط بنجاح للعضو ${adminGrantTarget}!`);
      
      // refresh
      const uRes = await fetch("/api/users");
      if (uRes.ok) setUsersList(await uRes.json());

    } catch (err: any) {
      setAdminError(err.message || "فشلت العملية لصعوبة بالصلاحيات.");
    }
  };

  // Admin/Moderator: Ban/Unban user from app
  const handleAdminToggleUserBan = async (target: string, shouldBan: boolean) => {
    if (!currentUser) return;
    if (!confirm(`هل تريد بالتأكيد ${shouldBan ? "حظر ودفع" : "إلغاء حظر"} المستخدم ${target}؟`)) return;

    try {
      const res = await fetch("/api/admin/toggle-user-ban", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetUsername: target,
          isBanned: shouldBan,
          actorAdmin: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      alert(`تم ${shouldBan ? "حظر" : "إلغاء حظر"} المستخدم بنجاح.`);
      
      // refresh
      const uRes = await fetch("/api/users");
      if (uRes.ok) setUsersList(await uRes.json());
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Admin/Moderator: Ban/Unban Community
  const handleAdminToggleCommunityBan = async (communityId: string, shouldBan: boolean) => {
    if (!currentUser) return;
    if (!confirm(`هل تريد بالتأكيد ${shouldBan ? "حظر وتجميد" : "إلغاء حظر وإعادة"} هذا المجتمع؟`)) return;

    try {
      const res = await fetch("/api/admin/toggle-community-ban", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          communityId,
          isBanned: shouldBan,
          actorAdmin: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      alert(`تم ${shouldBan ? "حظر" : "إلغاء تجميد"} المجتمع بالكامل.`);
      
      // select null if banned
      if (selectedCommunity?.id === communityId && shouldBan) {
        setSelectedCommunity(null);
      }

      // refresh
      const resComm = await fetch("/api/communities");
      if (resComm.ok) setCommunitiesList(await resComm.json());
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Ultimate Owner Admin: Manage Dynamic Moderators
  const handleAdminConfigureModerator = async (target: string, makeMod: boolean) => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/admin/manage-moderator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetUsername: target,
          isModerator: makeMod,
          actorAdmin: currentUser.username
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      alert(`تم تعديل الصلاحية بنجاح! ${target} الآن ${makeMod ? "مسؤول مساعد للشبكة" : "مستخدم عام"}`);
      
      // refresh
      const uRes = await fetch("/api/users");
      if (uRes.ok) setUsersList(await uRes.json());
    } catch (err: any) {
      alert(err.message);
    }
  };


  // If no user session, show stunning login/register/recovery screen
  if (!currentUser) {
    if (sessionLoading) {
      return (
        <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center text-white font-sans" dir="rtl">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-sm text-zinc-400 font-bold">بدء شبكة Friends الآمنة...</p>
        </div>
      );
    }
    return <AuthScreen onAuthSuccess={(user) => setCurrentUser(user)} />;
  }

  // General Filtered Lists
  const filteredCommunities = communitiesList.filter(c => 
    !c.isBanned && c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const friendsList = usersList.filter(u => 
    u.username.toLowerCase() !== currentUser.username.toLowerCase() &&
    (currentUser.friends || []).some(f => f.toLowerCase() === u.username.toLowerCase())
  );

  const isCurrentActiveUserModeratorOrAdmin = currentUser.isModerator || currentUser.username.toLowerCase() === "admin";

  return (
    <div className="min-h-screen w-full bg-[#0d0d0f] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-zinc-900 via-black to-[#050505] text-zinc-100 flex flex-col items-center justify-center p-2 sm:p-5 select-none overflow-auto font-sans" dir="rtl">
      
      {/* Dynamic Metallic Controller Panel for Android Emulator Selector */}
      <div className="w-full max-w-5xl mb-4 bg-zinc-900/50 border border-zinc-850 backdrop-blur-md p-2.5 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xl relative z-20 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-3 h-3 bg-orange-500 rounded-full animate-pulse shrink-0"></div>
          <div>
            <h1 className="text-xs font-black text-white tracking-wide uppercase">محاكي أندرويد الذكي لشبكة أصدقاء Friends 📱</h1>
            <p className="text-[9px] text-zinc-400">متصل بقاعدة وبنية بيانات سحابية حقيقية Firebase Firestore</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-zinc-500 ml-1">شاشة العرض:</span>
          
          <button 
            type="button"
            onClick={() => setDeviceModel("phone")} 
            className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
              deviceModel === "phone" ? "bg-orange-500 text-black shadow-md shadow-orange-500/10" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-755"
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            هاتف Android
          </button>

          <button 
            type="button"
            onClick={() => setDeviceModel("tablet")} 
            className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
              deviceModel === "tablet" ? "bg-orange-500 text-black shadow-md shadow-orange-500/10" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-755"
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 rotate-90" />
            تابلت لوحي
          </button>

          <button 
            type="button"
            onClick={() => setDeviceModel("fullscreen")} 
            className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
              deviceModel === "fullscreen" ? "bg-orange-500 text-black shadow-md shadow-orange-500/10" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-755"
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            كامل الشاشة
          </button>
        </div>
      </div>

      {/* Device frame casing container */}
      <div className={`transition-all duration-300 relative shrink-0 flex flex-col overflow-hidden ${
        deviceModel === "phone" 
          ? "w-[410px] h-[820px] border-[10px] border-zinc-805 rounded-[44px] shadow-2xl shadow-orange-500/5 ring-1 ring-zinc-700/50 bg-black" 
          : deviceModel === "tablet" 
          ? "w-[960px] h-[650px] border-[12px] border-zinc-850 rounded-[40px] shadow-2xl shadow-orange-500/5 ring-1 ring-zinc-700/50 bg-black" 
          : "w-full h-screen max-h-screen"
      }`}>
        
        {/* Real Dynamic Status Bar at top */}
        {deviceModel !== "fullscreen" && (
          <div className="w-full h-8 bg-[#121212] flex items-center justify-between px-5 select-none border-b border-zinc-900 text-zinc-400 text-[10px] font-mono shrink-0 z-40 relative">
            <div className="flex items-center gap-1">
              <span>5G</span>
              <svg className="w-3.5 h-3.5 shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L17.58 4.97C16.03 3.74 14.1 3 12 3zm5.61 3.39l-12.2 12.2C6.96 19.82 9.35 21 12 21c4.97 0 9-4.03 9-9 0-2.65-1.15-5.04-3.39-6.61z"/></svg>
              <svg className="w-3.5 h-3.5 shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M15.9 5c-.17 0-.32.09-.41.23L12 11.5l-3.49-6.27A.48.48 0 0 0 8.1 5h-4.8c-.37 0-.62.4-.44.73l7.98 14.36c.18.33.66.33.84 0l7.98-14.36c.18-.33-.07-.73-.44-.73h-3.26z"/></svg>
            </div>

            {/* Simulated Punch hole camera */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-zinc-950 rounded-full border border-zinc-800 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-blue-900 rounded-full opacity-60"></div>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="font-sans font-bold">{androidTime}</span>
              <div className="flex items-center gap-0.5 bg-zinc-800 px-1 rounded text-[9px] text-zinc-300">
                <span>⚡ 88%</span>
              </div>
            </div>
          </div>
        )}

        {/* Outer App content layout container */}
        <div 
          style={{ 
            backgroundImage: "linear-gradient(rgba(10, 10, 10, 0.94), rgba(10, 10, 10, 0.94)), url('/src/assets/images/friends_bg_1780026777426.png')",
            backgroundSize: "cover",
            backgroundPosition: "center"
          }}
          className="flex-1 w-full h-full min-h-0 flex overflow-hidden text-zinc-100 font-sans select-none relative"
        >
      
      {/* 1. Leftmost Rail Bar: Communities Quick Access (Vibrant Palette style) */}
      <aside className="w-20 bg-[#121212]/80 backdrop-blur-md flex flex-col items-center py-6 gap-6 border-l border-zinc-900 shrink-0">
        <div 
          onClick={() => { setSelectedCommunity(null); setSelectedFriendUsername(null); }}
          className="w-12 h-12 rounded-2xl flex items-center justify-center overflow-hidden shadow-lg hover:scale-105 transition-all select-none cursor-pointer border border-zinc-800 bg-zinc-950"
          title="الرئيسية"
        >
          <img 
            src="/src/assets/images/friends_logo_1780026753737.png" 
            alt="Friends Logo" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="w-10 h-0.5 bg-zinc-800 rounded-full"></div>
        
        {/* Dynamic community circles */}
        <div className="flex-1 w-full flex flex-col items-center gap-4 overflow-y-auto no-scrollbar">
          {communitiesList.filter(c => !c.isBanned && c.members.includes(currentUser.username)).map((comm) => (
            <button
              key={comm.id}
              onClick={() => {
                setSelectedCommunity(comm);
                setSelectedFriendUsername(null);
              }}
              className={`w-12 h-12 bg-zinc-800 rounded-full flex items-center justify-center cursor-pointer hover:border-orange-500 border-2 transition-all relative group ${
                selectedCommunity?.id === comm.id ? "border-orange-500 ring-2 ring-orange-500/20 rounded-2xl" : "border-zinc-800 hover:rounded-2xl"
              }`}
              title={comm.name}
            >
              <span className="text-xs font-bold text-orange-400">
                {comm.name.substring(0, 3).trim()}
              </span>
              {comm.owner === currentUser.username && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-black text-[8px] font-black px-1 rounded-sm">👑</span>
              )}
            </button>
          ))}

          {/* Create Community button */}
          <button
            onClick={() => {
              setShowCreateCommunity(true);
              setActiveSubTab("communities");
            }}
            className="w-12 h-12 bg-zinc-900 hover:bg-orange-600/10 hover:border-orange-500 rounded-full border-2 border-dashed border-zinc-700 flex items-center justify-center cursor-pointer text-orange-500 transition-all hover:rounded-2xl"
            title="إنشاء مجتمع جديد (يكلف 10 نقاط)"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Bottom Profile / Quick Info */}
        <div className="mt-auto flex flex-col items-center gap-4">
          <button 
            onClick={() => { setActiveSubTab("profile"); setSelectedCommunity(null); setSelectedFriendUsername(null); }}
            className="w-10 h-10 rounded-full bg-zinc-800 overflow-hidden border border-zinc-700 hover:border-orange-500 hover:scale-105 transition-all cursor-pointer"
            title="إعدادات الملف الشخصي"
          >
            <img 
              src={currentUser.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.username}`} 
              alt="Avatar" 
              className="w-full h-full object-cover" 
            />
          </button>
          <button
            onClick={handleLogout}
            className="w-10 h-10 bg-red-950/20 hover:bg-red-650 hover:text-red-500 rounded-lg flex items-center justify-center cursor-pointer text-zinc-500 transition-colors"
            title="تسجيل الخروج"
          >
            <LogOut className="w-5 h-5 text-red-400" />
          </button>
        </div>
      </aside>

      {/* 2. Middle control sidebar panel: Navigation & Lists */}
      <nav className={`w-72 bg-[#161616] flex flex-col border-l border-zinc-800 shrink-0 ${
        deviceModel === "phone" && (selectedCommunity || selectedFriendUsername) ? "hidden" : "flex"
      } md:flex`}>
        <div className="p-5 border-b border-zinc-900">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-2xl font-black bg-gradient-to-l from-orange-500 to-amber-400 bg-clip-text text-transparent">Friends HUB</h2>
            <div className="flex items-center gap-1 bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded-full text-[10px] font-bold">
              <Star className="w-3 h-3 fill-amber-500" />
              <span>{currentUser.points} FP</span>
            </div>
          </div>
          
          {/* Quick Option Buttons */}
          <div className="space-y-1">
            <button 
              onClick={() => { setActiveSubTab("communities"); setSelectedCommunity(null); setSelectedFriendUsername(null); }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-bold transition ${
                activeSubTab === "communities" && !selectedCommunity && !selectedFriendUsername
                  ? "bg-orange-600/10 text-orange-500 border-r-4 border-orange-500"
                  : "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200"
              }`}
            >
              <span className="flex items-center gap-2">
                <Hash className="w-4 h-4" />
                تصفح المجتمعات
              </span>
              <span className="px-1.5 py-0.5 bg-zinc-800 text-zinc-500 rounded text-[9px] font-mono">
                {communitiesList.length}
              </span>
            </button>

            <button 
              onClick={() => { setActiveSubTab("friends"); setSelectedCommunity(null); setSelectedFriendUsername(null); }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-bold transition ${
                activeSubTab === "friends" && !selectedCommunity && !selectedFriendUsername
                  ? "bg-orange-600/10 text-orange-500 border-r-4 border-orange-500"
                  : "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200"
              }`}
            >
              <span className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                الأصدقاء والمراسلات
              </span>
              <span className="px-1.5 py-0.5 bg-zinc-800 text-zinc-500 rounded text-[9px] font-mono">
                {friendsList.length}
              </span>
            </button>

            <button 
              onClick={() => { setActiveSubTab("profile"); setSelectedCommunity(null); setSelectedFriendUsername(null); }}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold transition ${
                activeSubTab === "profile" && !selectedCommunity && !selectedFriendUsername
                  ? "bg-orange-600/10 text-orange-500 border-r-4 border-orange-500"
                  : "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200"
              }`}
            >
              <Settings className="w-4 h-4" />
              تعديل ملفي الشخصي
            </button>

            {currentUser && currentUser.username.toLowerCase() === "admin" && (
              <button 
                onClick={() => { setActiveSubTab("admin"); setSelectedCommunity(null); setSelectedFriendUsername(null); }}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold transition ${
                  activeSubTab === "admin" && !selectedCommunity && !selectedFriendUsername
                    ? "bg-red-500/10 text-red-400 border-r-4 border-red-500"
                    : "text-zinc-500 hover:bg-zinc-800/30 hover:text-zinc-200"
                }`}
              >
                <ShieldAlert className="w-4 h-4" />
                لوحة الإدارة 1911
              </button>
            )}
          </div>
        </div>

        {/* Active list container based on SubTab selection */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* Active Contacts / Real-time activity */}
          <div>
            <div className="flex items-center justify-between mb-2 px-1">
              <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">مستخدمو المنصة النشطون</span>
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
            </div>

            <div className="space-y-1.5">
              {usersList.slice(0, 15).map((u) => {
                const isFriend = (currentUser.friends || []).includes(u.username);
                return (
                  <div 
                    key={u.username}
                    onClick={() => {
                      setSelectedFriendUsername(u.username);
                      setSelectedCommunity(null);
                      setActiveSubTab("friends");
                    }}
                    className={`flex items-center justify-between p-2 rounded-xl border transition cursor-pointer ${
                      selectedFriendUsername === u.username
                        ? "bg-orange-600/10 border-orange-500/40 text-orange-400"
                        : "bg-zinc-900/40 border-zinc-800/30 hover:bg-zinc-900 hover:border-zinc-800"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="relative shrink-0">
                        <img 
                          src={u.avatar} 
                          alt="Av" 
                          className="w-8 h-8 rounded-full border border-zinc-800 bg-zinc-950" 
                        />
                        <span className="absolute bottom-0 left-0 w-2.5 h-2.5 bg-green-500 border-2 border-[#161616] rounded-full"></span>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <p className="text-xs font-bold truncate text-zinc-200">{u.username}</p>
                          {u.username.toLowerCase() === "admin" && (
                            <span className="bg-amber-500/20 text-amber-500 text-[8px] px-1 font-bold rounded">المالك</span>
                          )}
                          {u.isModerator && u.username.toLowerCase() !== "admin" && (
                            <span className="bg-orange-500/20 text-orange-500 text-[8px] px-1 font-bold rounded">مسؤول</span>
                          )}
                        </div>
                        <p className="text-[9px] text-zinc-400 truncate max-w-[130px]">{u.status}</p>
                      </div>
                    </div>

                    {u.username !== currentUser.username && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleFriendship(u.username);
                        }}
                        className={`p-1.5 rounded transition ${
                          isFriend ? "text-orange-500 hover:text-red-400" : "text-zinc-650 hover:text-orange-400"
                        }`}
                        title={isFriend ? "إزالة من الأصدقاء" : "إضافة للأصدقاء"}
                      >
                        {isFriend ? <UserMinus className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sticky current logged user mini profile card at bottom */}
        <div className="p-4 bg-[#121212] border-t border-zinc-850">
          <div className="flex items-center gap-3">
            <div className="relative shrink-0 select-none">
              <img 
                src={currentUser.avatar} 
                alt="Avatar" 
                className="w-9 h-9 rounded-full border border-orange-500/40" 
              />
              <span className="absolute bottom-0 left-0 w-2.5 h-2.5 bg-green-500 border-2 border-[#121212] rounded-full"></span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-bold truncate text-white">{currentUser.username}</p>
                {currentUser.username.toLowerCase() === "admin" ? (
                  <span className="px-1 text-[8px] font-black bg-amber-500 text-black rounded uppercase">MGR</span>
                ) : currentUser.isModerator ? (
                  <span className="px-1 text-[8px] font-black bg-orange-500 text-black rounded uppercase">MOD</span>
                ) : null}
              </div>
              <p className="text-[10px] text-zinc-500 truncate">{currentUser.phone}</p>
            </div>
            <button 
              onClick={() => { setActiveSubTab("profile"); setSelectedCommunity(null); setSelectedFriendUsername(null); }}
              className="p-1.5 hover:bg-zinc-800 rounded text-zinc-400 hover:text-orange-500 transition cursor-pointer"
            >
              <Settings className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* 3. Main content viewport area (Messages / Screens) */}
      <main className={`flex-1 flex flex-col bg-[#0F0F0F] relative overflow-hidden ${
        deviceModel === "phone" && !(selectedCommunity || selectedFriendUsername) ? "hidden" : "flex"
      } md:flex`}>
        
        {/* Active Header bar */}
        <header className="h-16 border-b border-zinc-800 flex items-center justify-between px-6 bg-[#121212] z-10">
          <div className="flex items-center gap-2.5 min-w-0">
            {deviceModel === "phone" && (selectedCommunity || selectedFriendUsername) && (
              <button
                type="button"
                onClick={() => { setSelectedCommunity(null); setSelectedFriendUsername(null); }}
                className="p-1.5 bg-zinc-800 hover:bg-zinc-750 text-orange-500 rounded-lg shrink-0 ml-1.5 cursor-pointer flex items-center justify-center transition"
                title="رجوع للقائمة"
              >
                <ArrowRight className="w-5 h-5" />
              </button>
            )}
            {selectedCommunity ? (
              <>
                <div className="inline-flex items-center justify-center w-8 h-8 bg-orange-600/10 text-orange-500 rounded-lg">
                  <Hash className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h1 className="text-sm font-bold truncate text-white">{selectedCommunity.name}</h1>
                    <span className="px-1.5 py-0.5 bg-orange-600/20 text-orange-500 text-[9px] font-bold rounded">
                      {selectedCommunity.members.length} عضو
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-500 truncate">{selectedCommunity.description}</p>
                </div>
              </>
            ) : selectedFriendUsername ? (
              <>
                <div className="relative">
                  <img 
                    src={usersList.find(u => u.username.toLowerCase() === selectedFriendUsername.toLowerCase())?.avatar || "https://api.dicebear.com/7.x/avataaars/svg?seed=friend"} 
                    alt="Friend avatar" 
                    className="w-8 h-8 rounded-full border border-zinc-700 bg-zinc-900" 
                  />
                  <span className="absolute bottom-0 left-0 w-2.5 h-2.5 bg-green-500 border-2 border-[#121212] rounded-full"></span>
                </div>
                <div>
                  <h1 className="text-sm font-bold text-white">دردشة خاصة: {selectedFriendUsername}</h1>
                  <p className="text-[10px] text-zinc-500">
                    {usersList.find(u => u.username.toLowerCase() === selectedFriendUsername.toLowerCase())?.status || "متاح الآن"}
                  </p>
                </div>
              </>
            ) : (
              <div>
                <h1 className="text-base font-black text-white">منصة الأصدقاء والمجتمعات Friends 🧡</h1>
                <p className="text-xs text-zinc-500">اختر مجتمعاً أو صديقاً لبدء التواصل صوتاً ونصاً</p>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {selectedCommunity && (
              <>
                {activeVoiceStream?.communityId === selectedCommunity.id ? (
                  <button 
                    onClick={handleLeaveVoiceStream}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-lg shadow-red-950/20 animate-pulse"
                  >
                    <VolumeX className="w-3.5 h-3.5" />
                    مغادرة البث الصوتي
                  </button>
                ) : (
                  <button 
                    onClick={() => handleJoinVoiceStream(selectedCommunity.id)}
                    className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-black text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-lg shadow-orange-950/20"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    انضمام للبث الصوتي
                  </button>
                )}
                
                {selectedCommunity.owner !== currentUser.username && (
                  <button 
                    onClick={() => handleLeaveCommunity(selectedCommunity.id)}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold rounded-lg cursor-pointer"
                  >
                    مغادرة
                  </button>
                )}
              </>
            )}
          </div>
        </header>

        {/* Content switch box */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* Main central chat viewport or selected settings forms */}
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* If a Community is active */}
            {selectedCommunity ? (
              <div className="flex-1 flex flex-col overflow-hidden">
                
                {/* Voice Broadcast status header panel inside active Community */}
                {activeVoiceStream?.communityId === selectedCommunity.id && (
                  <div className="bg-zinc-950/90 border-b border-orange-500/20 p-4 shrink-0 transition-all">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2 text-orange-500">
                        <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping"></span>
                        <span className="text-xs font-black uppercase tracking-wider">بث صوتي نشط الآن</span>
                      </div>
                      
                      {/* Self stream indicators */}
                      <div className="flex items-center gap-3">
                        <button
                          onMouseDown={() => handleSimulateSpeaking(true)}
                          onMouseUp={() => handleSimulateSpeaking(false)}
                          onTouchStart={() => handleSimulateSpeaking(true)}
                          onTouchEnd={() => handleSimulateSpeaking(false)}
                          disabled={isSelfVoiceMuted}
                          className={`px-3 py-1 text-[10px] font-bold rounded-md select-none ${
                            isSelfVoiceMuted 
                              ? "bg-zinc-800 text-zinc-500 cursor-not-allowed" 
                              : "bg-orange-600 hover:bg-orange-500 active:bg-orange-700 text-black cursor-pointer"
                          }`}
                        >
                          اضغط للتحدث 🎙️ (اضغط مطولاً)
                        </button>

                        <button
                          onClick={handleToggleSelfMuteInStream}
                          className={`p-1.5 rounded-lg ${isSelfVoiceMuted ? "bg-red-950/50 text-red-500 border border-red-850" : "bg-zinc-850 text-zinc-400"}`}
                          title={isSelfVoiceMuted ? "إلغاء كتم مايكروفونك" : "كتم مايكروفونك"}
                        >
                          {isSelfVoiceMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Participant bubbles grid */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {activeVoiceStream.participants.map((p) => {
                        const isThisMe = p.username.toLowerCase() === currentUser.username.toLowerCase();
                        const isOwner = selectedCommunity.owner === p.username;
                        const isAdmin = selectedCommunity.admins.includes(p.username);
                        
                        return (
                          <div 
                            key={p.username} 
                            className={`p-2.5 rounded-xl flex items-center gap-2.5 border transition ${
                              p.isSpeaking 
                                ? "bg-orange-600/10 border-orange-500 ring-2 ring-orange-500/30" 
                                : "bg-[#161616] border-zinc-800"
                            }`}
                          >
                            <div className="relative shrink-0">
                              <div className={`w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center font-bold text-xs select-none ${p.isSpeaking ? "ring-2 ring-orange-500" : ""}`}>
                                {p.username.substring(0, 2).toUpperCase()}
                              </div>
                              {p.isMuted && (
                                <span className="absolute -bottom-1 -right-1 bg-red-600 text-white text-[9px] p-0.5 rounded-md">
                                  <VolumeX className="w-2.5 h-2.5" />
                                </span>
                              )}
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-xs font-bold truncate text-zinc-200">{p.username}</p>
                              <div className="flex gap-1">
                                {isOwner ? (
                                  <span className="text-[7px] bg-amber-500 text-black px-1 rounded">المنشئ</span>
                                ) : isAdmin ? (
                                  <span className="text-[7px] bg-orange-500 text-semibold px-1 rounded">مشرف</span>
                                ) : (
                                  <span className="text-[7px] bg-zinc-800 text-zinc-500 px-1 rounded">مستمع</span>
                                )}
                                {!p.canSpeak && <span className="text-[7px] bg-red-950 text-red-400 px-1 rounded">محظور التحدث</span>}
                              </div>
                              {p.isSpeaking && <span className="text-[8px] text-orange-400 animate-pulse font-bold block">يتحدث...</span>}
                            </div>

                            {/* Stream action tools for OWNER / ADMINS */}
                            {(selectedCommunity.owner === currentUser.username || selectedCommunity.admins.includes(currentUser.username)) && !isThisMe && (
                              <div className="flex items-center gap-1 shrink-0">
                                {p.canSpeak ? (
                                  <button
                                    onClick={() => handleVoiceParticipantControl(p.username, "block")}
                                    className="p-1 hover:bg-zinc-800 text-amber-500 rounded"
                                    title="منع من التحدث"
                                  >
                                    <MicOff className="w-3 h-3" />
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleVoiceParticipantControl(p.username, "allow")}
                                    className="p-1 hover:bg-zinc-800 text-green-500 rounded"
                                    title="السماح بالتحدث"
                                  >
                                    <Mic className="w-3 h-3" />
                                  </button>
                                )}
                                <button
                                  onClick={() => handleVoiceParticipantControl(p.username, "kick")}
                                  className="p-1 hover:bg-zinc-800 text-red-500 rounded"
                                  title="إخراج من المكالمة"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Messages feed */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {communityMessages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-zinc-500 p-8 text-center">
                      <MessageSquare className="w-12 h-12 text-zinc-850 mb-3" />
                      <p className="text-sm font-bold">بداية المجتمع ممتازة!</p>
                      <p className="text-xs text-zinc-600 mt-1">تكلم أولاً، شارك فكرة مجتمعك مع الآخرين.</p>
                    </div>
                  ) : (
                    communityMessages.map((msg) => {
                      const isMe = msg.sender.toLowerCase() === currentUser.username.toLowerCase();
                      const isOwner = selectedCommunity.owner === msg.sender;
                      const isAdmin = selectedCommunity.admins.includes(msg.sender);
                      
                      return (
                        <div key={msg.id} className={`flex items-start gap-3 max-w-2xl ${isMe ? "bg-orange-600/5 p-2 rounded-xl border border-orange-500/10 mr-auto" : "ml-auto"}`}>
                          <div className="w-9 h-9 bg-zinc-800 rounded-lg flex items-center justify-center font-bold text-xs select-none shrink-0 border border-zinc-700">
                            {msg.sender.substring(0, 2).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-black text-orange-400">{msg.sender}</span>
                              {isOwner ? (
                                <span className="text-[8px] bg-amber-500 text-black font-black px-1 rounded leading-none shrink-0 font-sans">المنشئ</span>
                              ) : isAdmin ? (
                                <span className="text-[8px] bg-yellow-500/20 text-yellow-500 font-bold px-1 rounded leading-none shrink-0">أدمن</span>
                              ) : null}
                              <span className="text-[9px] text-zinc-600">
                                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-sm text-zinc-300 whitespace-normal break-words leading-relaxed">{msg.text}</p>
                          </div>
                        </div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Text sender controller */}
                <form onSubmit={handleSendMessage} className="p-4 bg-[#121212] border-t border-zinc-900 flex items-center gap-3">
                  <div className="flex-1 bg-[#0A0A0A] rounded-xl px-4 py-3 flex items-center border border-zinc-800 focus-within:border-orange-500/50">
                    <input 
                      type="text" 
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder={`اكتب رسالة في المجتمع #${selectedCommunity.name}`} 
                      className="bg-transparent w-full text-sm outline-none placeholder-zinc-650 text-white text-right"
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-11 h-11 bg-orange-600 hover:bg-orange-500 active:bg-orange-700 rounded-xl flex items-center justify-center cursor-pointer text-black font-black transition-all"
                  >
                    <Send className="w-5 h-5 shrink-0 transform rotate-180" />
                  </button>
                </form>

              </div>
            ) : selectedFriendUsername ? (
              // Private One-on-one Chat Room
              <div className="flex-1 flex flex-col overflow-hidden">
                
                {/* Chat items message lists */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {privateMessages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-zinc-500 p-8 text-center">
                      <MessageSquare className="w-12 h-12 text-zinc-850 mb-3" />
                      <p className="text-sm font-bold">بداية الدردشة الخاصة الآمنة</p>
                      <p className="text-xs text-zinc-600 mt-1">الرسائل بين حسابيكما آمنة، مشفرة، ومحفوظة على الخادم.</p>
                    </div>
                  ) : (
                    privateMessages.map((msg) => {
                      const isMe = msg.from.toLowerCase() === currentUser.username.toLowerCase();
                      return (
                        <div 
                          key={msg.id} 
                          className={`flex items-start gap-3 max-w-lg p-2 rounded-xl transition ${
                            isMe 
                              ? "bg-orange-500/10 border border-orange-500/10 mr-auto flex-row-reverse" 
                              : "bg-zinc-900/40 border border-zinc-800/50 ml-auto"
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-zinc-800 shrink-0 border border-zinc-700 flex items-center justify-center font-bold text-[10px] select-none text-orange-400">
                            {msg.from.substring(0, 2).toUpperCase()}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 mb-1 justify-between">
                              <span className="text-xs font-bold text-zinc-200">{msg.from}</span>
                              <span className="text-[9px] text-zinc-600">
                                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-sm text-zinc-300 break-words leading-relaxed">{msg.text}</p>
                          </div>
                        </div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Sender Form */}
                <form onSubmit={handleSendMessage} className="p-4 bg-[#121212] border-t border-zinc-900 flex items-center gap-3">
                  <div className="flex-1 bg-[#0A0A0A] rounded-xl px-4 py-3 flex items-center border border-zinc-800 focus-within:border-orange-500/50">
                    <input 
                      type="text" 
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder={`أرسل رسالة خاصة آمنة إلى ${selectedFriendUsername}`} 
                      className="bg-transparent w-full text-sm outline-none placeholder-zinc-650 text-white text-right"
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-11 h-11 bg-orange-600 hover:bg-orange-500 active:bg-orange-700 rounded-xl flex items-center justify-center cursor-pointer text-black font-black transition-all"
                  >
                    <Send className="w-5 h-5 shrink-0 transform rotate-180" />
                  </button>
                </form>

              </div>
            ) : (
              // Active SubTab Screens if no target selected
              <div className="flex-1 overflow-y-auto p-6 md:p-8">
                
                {/* 1. COMMUNITIES TAB */}
                {activeSubTab === "communities" && (
                  <div className="space-y-6">
                    
                    {/* Header with Search and Create button */}
                    <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 bg-zinc-900/60 p-5 rounded-2xl border border-zinc-850">
                      <div>
                        <h2 className="text-xl font-extrabold text-orange-500">استوديو المجتمعات 🌐</h2>
                        <p className="text-xs text-zinc-400 mt-1">تداول المعرفة والمجالس الصوتية مع مستخدمي Friends.</p>
                      </div>
                      
                      <div className="flex items-center gap-3 shrink-0">
                        <input
                          type="text"
                          placeholder="ابحث عن مجتمع..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="px-3.5 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded-lg text-white placeholder-zinc-650 outline-none focus:border-orange-500"
                        />
                        <button
                          onClick={() => setShowCreateCommunity(true)}
                          className="px-4 py-2 bg-orange-600 hover:bg-orange-500 active:bg-orange-700 text-black text-xs font-black rounded-lg cursor-pointer flex items-center gap-1"
                        >
                          <Plus className="w-4 h-4" />
                          مجتمع جديد (FP 10)
                        </button>
                      </div>
                    </div>

                    {/* Create Community Inline Overlay Form */}
                    {showCreateCommunity && (
                      <form onSubmit={handleCreateCommunity} className="bg-zinc-900 border border-orange-500/20 p-5 rounded-2xl space-y-4">
                        <div className="pb-2 border-b border-zinc-850 flex items-center justify-between">
                          <h3 className="text-sm font-bold text-orange-400 flex items-center gap-1.5">
                            <Hash className="w-5 h-5 text-orange-500" />
                            إنشاء مجتمع جديد مخصص بالنقاط
                          </h3>
                          <button 
                            type="button" 
                            onClick={() => setShowCreateCommunity(false)}
                            className="text-zinc-500 hover:text-white"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        
                        <p className="text-[10px] text-zinc-400 leading-relaxed">
                          🛡️ سيتطلب منك دفع <strong>10 نقاط (10 FP)</strong> من ميزانيتك الحالية ({currentUser.points} FP) لتأسيس مجتمع جديد.
                        </p>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold text-zinc-300 mb-1">اسم المجتمع</label>
                            <input
                              type="text"
                              required
                              value={newCommunityName}
                              onChange={(e) => setNewCommunityName(e.target.value)}
                              placeholder="مثال: عشاق التصميم والألعاب 🎮"
                              className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-zinc-300 mb-1">الوصف العام</label>
                            <input
                              type="text"
                              value={newCommunityDesc}
                              onChange={(e) => setNewCommunityDesc(e.target.value)}
                              placeholder="ماذا يناقش هذا المجتمع؟"
                              className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                            />
                          </div>
                        </div>

                        <div className="flex justify-end gap-3 pt-2">
                          <button
                            type="button"
                            onClick={() => setShowCreateCommunity(false)}
                            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-xs text-zinc-300"
                          >
                            إلغاء التأسيس
                          </button>
                          <button
                            type="submit"
                            className="px-5 py-2 bg-orange-600 hover:bg-orange-500 text-black font-extrabold text-xs rounded-lg cursor-pointer"
                          >
                            خصم 10 نقاط والتفعيل فورياً
                          </button>
                        </div>
                      </form>
                    )}

                    {/* Communities Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {filteredCommunities.map((comm) => {
                        const isMember = comm.members.includes(currentUser.username);
                        const isPending = comm.joinRequests.includes(currentUser.username);
                        
                        return (
                          <div 
                            key={comm.id} 
                            className={`p-5 rounded-2xl border bg-zinc-900/40 relative flex flex-col justify-between transition min-h-[160px] ${
                              isMember ? "border-orange-500/20" : "border-zinc-800/80"
                            }`}
                          >
                            {/* Card Content */}
                            <div>
                              <div className="flex items-center justify-between mb-2">
                                <h3 className="font-bold text-white text-base truncate pr-2">{comm.name}</h3>
                                {comm.owner === currentUser.username ? (
                                  <span className="bg-amber-500/15 text-amber-500 text-[10px] px-2 py-0.5 rounded-full font-bold">ملكي</span>
                                ) : comm.admins.includes(currentUser.username) ? (
                                  <span className="bg-orange-500/10 text-orange-400 text-[10px] px-2 py-0.5 rounded-full font-bold">أدمن</span>
                                ) : isMember ? (
                                  <span className="bg-zinc-800 text-zinc-400 text-[10px] px-2 py-0.5 rounded-full font-bold">عضو منضم</span>
                                ) : null}
                              </div>
                              <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed mb-4">{comm.description}</p>
                            </div>

                            {/* Info & Bottom button row */}
                            <div className="flex items-center justify-between pt-4 border-t border-zinc-850 mt-auto">
                              <span className="text-[10px] text-zinc-550 font-semibold flex items-center gap-1">
                                <Users className="w-3.5 h-3.5 text-zinc-650" />
                                {comm.members.length} عضو منضم
                              </span>

                              {isMember ? (
                                <button
                                  onClick={() => {
                                    setSelectedCommunity(comm);
                                    setSelectedFriendUsername(null);
                                  }}
                                  className="px-4 py-1.5 bg-zinc-800 hover:bg-orange-600 hover:text-white transition-all text-orange-400 text-xs font-bold rounded-lg cursor-pointer"
                                >
                                  دخول المجتمع ➔
                                </button>
                              ) : isPending ? (
                                <button
                                  disabled
                                  className="px-4 py-1.5 bg-zinc-900 text-zinc-600 text-xs font-bold rounded-lg border border-zinc-800"
                                >
                                  قيد موافقة الأدمن...
                                </button>
                              ) : (
                                <button
                                  onClick={() => handleSendJoinRequest(comm.id)}
                                  className="px-4 py-1.5 bg-orange-600 hover:bg-orange-500 text-black text-xs font-black rounded-lg cursor-pointer"
                                >
                                  إرسال طلب انضمام 🕊️
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}

                      {filteredCommunities.length === 0 && (
                        <div className="col-span-1 md:col-span-2 text-center p-12 bg-zinc-900/20 border border-dashed border-zinc-800 rounded-2xl text-zinc-500">
                          <Users className="w-10 h-10 text-zinc-800 mx-auto mb-2" />
                          <p className="text-sm font-bold">لا توجد مجتمعات متوفرة حالياً</p>
                          <p className="text-xs text-zinc-600 mt-1">ابدأ بـتأسيس مجتمعك الخاص بالنقاط والريادة!</p>
                        </div>
                      )}
                    </div>

                  </div>
                )}

                {/* 2. FRIENDS DIRECT TAB */}
                {activeSubTab === "friends" && (
                  <div className="space-y-6">
                    <div className="bg-zinc-900/60 p-5 rounded-2xl border border-zinc-850">
                      <h2 className="text-xl font-extrabold text-orange-500">صفحة الأصدقاء والمراسلات الخاصة 📬</h2>
                      <p className="text-xs text-zinc-400 mt-1">اضغط على أي صديق لبدء محادثة مشفرة ومحفوظة معه في الحال.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {friendsList.map((friend) => (
                        <div 
                          key={friend.username} 
                          className="bg-zinc-900/50 hover:bg-zinc-900 rounded-2xl p-5 border border-zinc-850 flex flex-col items-center text-center justify-between"
                        >
                          <div className="flex flex-col items-center">
                            <img 
                              src={friend.avatar} 
                              alt="Av" 
                              className="w-14 h-14 rounded-full border border-orange-550/30 bg-zinc-950 p-0.5 mb-3" 
                            />
                            <h3 className="font-bold text-white text-base">{friend.username}</h3>
                            <span className="text-[10px] px-2 py-0.5 bg-zinc-850 text-orange-400 rounded-full font-semibold mt-1">
                              {friend.points} FP
                            </span>
                            <p className="text-xs text-zinc-400 mt-2.5 max-h-12 line-clamp-2 leading-relaxed px-2">
                              {friend.status || "لا يوجد حالة مكتوبة مسبقاً."}
                            </p>
                          </div>

                          <div className="w-full flex gap-2 mt-5 pt-4 border-t border-zinc-850">
                            <button
                              onClick={() => {
                                setSelectedFriendUsername(friend.username);
                                setSelectedCommunity(null);
                              }}
                              className="flex-1 py-1.5 bg-orange-600 hover:bg-orange-500 active:bg-orange-700 text-black text-xs font-black rounded-lg cursor-pointer transition-all"
                            >
                              دردشة خاصة 💬
                            </button>
                            
                            <button
                              onClick={() => {
                                handleToggleFriendship(friend.username);
                              }}
                              className="px-2.5 py-1.5 bg-red-955/20 hover:bg-red-900 text-red-500 text-xs rounded-lg hover:text-white transition-all"
                              title="إلغاء صداقة"
                            >
                              إزالة ❌
                            </button>
                          </div>
                        </div>
                      ))}

                      {friendsList.length === 0 && (
                        <div className="col-span-1 md:col-span-3 text-center p-12 bg-zinc-900/20 border border-dashed border-zinc-800 rounded-2xl text-zinc-550">
                          <Users className="w-10 h-10 text-zinc-800 mx-auto mb-2" />
                          <p className="text-sm font-bold">لا يوجد أصدقاء نشطون مضافون بعد</p>
                          <p className="text-xs text-zinc-650 mt-1">اضغط على أي مستخدم نشط من القائمة الجانبية لإضافته وبدء المحادثة معه!</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* 3. PROFILE SETTINGS TAB */}
                {activeSubTab === "profile" && (
                  <div className="space-y-6">
                    <div className="bg-zinc-900/60 p-5 rounded-2xl border border-zinc-850">
                      <h2 className="text-xl font-extrabold text-orange-500">إعدادات ملفي الشخصي ⚙️</h2>
                      <p className="text-xs text-zinc-400 mt-1">قم بتحديث معلوماتك الأساسية لظهور مميز أمام بقية الأصدقاء.</p>
                    </div>

                    <form onSubmit={handleUpdateProfile} className="bg-zinc-900 border border-zinc-850 p-6 md:p-8 rounded-2xl space-y-5">
                      
                      {settingsSuccess && (
                        <div className="p-3.5 bg-green-950/40 border border-green-800/60 rounded-xl text-green-200 text-xs flex items-center gap-2">
                          <Check className="w-4.5 h-4.5 text-green-500 shrink-0" />
                          <span>{settingsSuccess}</span>
                        </div>
                      )}

                      {settingsError && (
                        <div className="p-3.5 bg-red-950/40 border border-red-800/60 rounded-xl text-red-200 text-xs flex items-center gap-2">
                          <AlertTriangle className="w-4.5 h-4.5 text-red-500 shrink-0" />
                          <span>{settingsError}</span>
                        </div>
                      )}

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        
                        <div>
                          <label className="block text-xs font-bold text-zinc-350 mb-1.5">اسم الحساب (غير قابل للتعديل)</label>
                          <input
                            type="text"
                            disabled
                            value={currentUser.username}
                            className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-900 rounded-xl text-xs text-zinc-500 cursor-not-allowed font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-zinc-350 mb-1.5">رقم الهاتف الأساسي (وسيلة الاستعادة)</label>
                          <div className="relative">
                            <input
                              type="tel"
                              required
                              value={editPhone}
                              onChange={(e) => setEditPhone(e.target.value)}
                              className="w-full pl-3 pr-10 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-white"
                            />
                            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-550">
                              <Smartphone className="w-4 h-4" />
                            </div>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-zinc-350 mb-1.5">رابط صورتك الشخصية</label>
                          <div className="relative">
                            <input
                              type="url"
                              value={editAvatar}
                              onChange={(e) => setEditAvatar(e.target.value)}
                              className="w-full pl-3 pr-10 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-white font-mono text-left"
                              dir="ltr"
                            />
                            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-550">
                              <Image className="w-4 h-4" />
                            </div>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-zinc-355 mb-1.5">الحالة الشخصية (Status)</label>
                          <input
                            type="text"
                            value={editStatus}
                            onChange={(e) => setEditStatus(e.target.value)}
                            className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-white"
                            placeholder="مثال: متاح للتطوير 🚀"
                          />
                        </div>

                        <div className="col-span-1 md:col-span-2 p-4 bg-zinc-950 border border-zinc-800 rounded-xl space-y-4">
                          <h4 className="text-xs font-bold text-orange-400 flex items-center gap-1">
                            <Key className="w-3.5 h-3.5" />
                            محرك حماية الحساب: تغيير كلمة المرور
                          </h4>
                          <div>
                            <label className="block text-[10px] text-zinc-455 mb-1">اترك هذا الحقل فارغاً في حال عدم رغبتك بتغيير كلمة المرور الحالية</label>
                            <input
                              type="password"
                              value={editPassword}
                              onChange={(e) => setEditPassword(e.target.value)}
                              className="w-full px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-xs text-white"
                              placeholder="أدخل الرمز السري الجديد هنا"
                            />
                          </div>
                        </div>

                      </div>

                      <div className="pt-4 border-t border-zinc-850 flex justify-end">
                        <button
                          type="submit"
                          className="px-6 py-2.5 bg-gradient-to-r from-orange-650 to-amber-600 hover:from-orange-700 text-black font-black text-xs rounded-xl shadow-lg cursor-pointer transition"
                        >
                          تأكيد وحفظ الإعدادات الشخصية
                        </button>
                      </div>

                    </form>
                  </div>
                )}

                {/* 4. ADMIN PANEL TAB (1911 KEY REQUIRED) */}
                {activeSubTab === "admin" && currentUser && currentUser.username.toLowerCase() === "admin" && (
                  <div className="space-y-6">
                    <div className="bg-gradient-to-l from-red-950/20 to-zinc-90 w-full p-5 rounded-2xl border border-red-900/20">
                      <h2 className="text-xl font-extrabold text-red-500">لوحة إدارة النظام العام (1911) 👑</h2>
                      <p className="text-xs text-zinc-400 mt-1">
                        لوحة خاصة بمالك تطبيق Friends. يرجى إدخال شفرة الأمان لتفعيل العمليات.
                      </p>
                    </div>

                    {!isAdminPanelUnlocked ? (
                      <form onSubmit={handleValidatePasscode} className="bg-zinc-900 border border-zinc-850 p-6 rounded-2xl space-y-4 max-w-md mx-auto">
                        <div className="text-center">
                          <ShieldAlert className="w-10 h-10 text-orange-600 mx-auto mb-2" />
                          <h3 className="text-sm font-bold text-zinc-200">التحقق من رمز الدخول</h3>
                          <p className="text-[10px] text-zinc-500 mt-1">يرجى إدخال كود الفتح والتحقق لفتح خصائص المراقبة والتحكم.</p>
                        </div>

                        <div>
                          <input
                            type="password"
                            required
                            value={adminPasscode}
                            onChange={(e) => setAdminPasscode(e.target.value)}
                            className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-center text-sm text-white font-mono tracking-widest placeholder-zinc-700"
                            placeholder="أدخل الشفرة e.g. 1911"
                          />
                        </div>

                        {adminError && <p className="text-xs text-red-400 text-center font-bold">{adminError}</p>}

                        <button
                          type="submit"
                          className="w-full py-2.5 bg-orange-600 hover:bg-orange-500 text-black font-bold text-xs rounded-xl cursor-pointer"
                        >
                          إلغاء قفل واجهة الرقابة العامة
                        </button>
                      </form>
                    ) : (
                      // Unlocked Admin Panel Operations
                      <div className="space-y-6">
                        
                        {/* Status bar */}
                        <div className="p-4 bg-zinc-900 rounded-xl border border-orange-500/10 flex flex-col md:flex-row items-center justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <ShieldCheck className="w-5 h-5 text-green-500" />
                            <div>
                              <p className="text-xs font-bold text-zinc-200">اللوحة مفتوحة ونشطة</p>
                              <p className="text-[10px] text-zinc-550">المشرف النشط: {currentUser.username}</p>
                            </div>
                          </div>
                          
                          <button
                            onClick={() => setIsAdminPanelUnlocked(false)}
                            className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 rounded-md text-[10px] font-bold"
                          >
                            قفل لوحة التحكم
                          </button>
                        </div>

                        {adminSuccess && (
                          <div className="p-3 bg-green-950/40 border border-green-800/60 rounded-xl text-green-200 text-xs flex items-center gap-2">
                            <Check className="w-4.5 h-4.5 text-green-500 shrink-0" />
                            <span>{adminSuccess}</span>
                          </div>
                        )}

                        {adminError && (
                          <div className="p-3 bg-red-950/40 border border-red-800/60 rounded-xl text-red-200 text-xs flex items-center gap-2">
                            <AlertTriangle className="w-4.5 h-4.5 text-red-500 shrink-0" />
                            <span>{adminError}</span>
                          </div>
                        )}

                        {/* Operation A: Grant Points (Only Allowed if Admin or Moderator privilege allows) */}
                        <div className="bg-zinc-900 border border-zinc-850 p-6 rounded-2xl space-y-4">
                          <h3 className="text-sm font-bold text-orange-400 flex items-center gap-1">
                            <Award className="w-4 h-4 text-orange-500" />
                            إرسال ومنح النقاط للمستخدمين (إثراء)
                          </h3>
                          <p className="text-[10px] text-zinc-450 leading-relaxed">
                            تُستخدم النقاط داخل تطبيق Friends بشكل أساسي لإنشاء وتأسيس مجتمعات حرة ونظامية.
                          </p>

                          <form onSubmit={handleAdminGrantPoints} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                            <div>
                              <label className="block text-[10px] font-bold text-zinc-450 mb-1">المستخدم المستهدف</label>
                              <select
                                required
                                value={adminGrantTarget}
                                onChange={(e) => setAdminGrantTarget(e.target.value)}
                                className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                              >
                                <option value="">-- اختر مستخدماً --</option>
                                {usersList.map(u => (
                                  <option key={u.username} value={u.username}>{u.username} (معه {u.points} FP)</option>
                                ))}
                              </select>
                            </div>

                            <div>
                              <label className="block text-[10px] font-bold text-zinc-450 mb-1">كمية النقاط الإضافية</label>
                              <input
                                type="number"
                                min="1"
                                required
                                value={adminGrantPoints}
                                onChange={(e) => setAdminGrantPoints(e.target.value)}
                                className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                              />
                            </div>

                            <button
                              type="submit"
                              className="py-2 px-4 bg-orange-600 hover:bg-orange-500 text-black text-xs font-black rounded-lg cursor-pointer transition"
                            >
                              تأكيد تحويل النقاط للعضو
                            </button>
                          </form>
                        </div>

                        {/* Operation B: Manage Users Ban lists (Total Ban) */}
                        <div className="bg-zinc-900 border border-zinc-850 p-6 rounded-2xl space-y-4">
                          <h3 className="text-sm font-bold text-red-500 flex items-center gap-1">
                            <ShieldAlert className="w-4 h-4 text-red-500" />
                            رقابة وحظر حسابات المستخدمين من المنصة
                          </h3>
                          
                          <div className="overflow-x-auto">
                            <table className="w-full text-right text-xs">
                              <thead>
                                <tr className="border-b border-zinc-800 text-zinc-500">
                                  <th className="pb-2">اسم الحساب</th>
                                  <th className="pb-2">المخالفات / الحالة</th>
                                  <th className="pb-2 text-left">التحكم</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-850">
                                {usersList.map((usr) => {
                                  const isPredefinedAdmin = usr.username.toLowerCase() === "admin";
                                  const isMe = usr.username.toLowerCase() === currentUser.username.toLowerCase();
                                  
                                  return (
                                    <tr key={usr.username} className="hover:bg-zinc-950/40">
                                      <td className="py-2 font-mono flex items-center gap-2">
                                        <img src={usr.avatar} alt="Av" className="w-6 h-6 rounded-full" />
                                        <span>{usr.username}</span>
                                        {isPredefinedAdmin && <span className="bg-amber-500 text-black text-[8px] font-black px-1 rounded">المالك الأصلي</span>}
                                      </td>
                                      <td className="py-2">
                                        {usr.isBanned ? (
                                          <span className="text-red-500 font-bold">● محظور من النظام</span>
                                        ) : (
                                          <span className="text-green-500 font-semibold">● متصل ونشط</span>
                                        )}
                                      </td>
                                      <td className="py-2 text-left">
                                        {!isPredefinedAdmin && !isMe && (
                                          <div className="inline-flex gap-2">
                                            {/* Ban / Unban toggler */}
                                            {usr.isBanned ? (
                                              <button
                                                onClick={() => handleAdminToggleUserBan(usr.username, false)}
                                                className="px-2.5 py-1 bg-green-950 hover:bg-green-900 text-green-400 rounded text-[10px] font-bold"
                                              >
                                                إلغاء الحظر
                                              </button>
                                            ) : (
                                              <button
                                                onClick={() => handleAdminToggleUserBan(usr.username, true)}
                                                className="px-2.5 py-1 bg-red-950 hover:bg-red-900 text-red-400 rounded text-[10px] font-bold"
                                              >
                                                حظر الحساب 🚫
                                              </button>
                                            )}

                                            {/* Promote moderator (Only allowed if currentUser is exactly the main admin) */}
                                            {currentUser.username.toLowerCase() === "admin" && (
                                              usr.isModerator ? (
                                                <button
                                                  onClick={() => handleAdminConfigureModerator(usr.username, false)}
                                                  className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 rounded text-[10px] font-bold"
                                                >
                                                  عزل رتبة مسؤول
                                                </button>
                                              ) : (
                                                <button
                                                  onClick={() => handleAdminConfigureModerator(usr.username, true)}
                                                  className="px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 rounded text-[10px] font-bold border border-amber-550/25"
                                                >
                                                  تعيين رتبة مسؤول ⭐
                                                </button>
                                              )
                                            )}
                                          </div>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>

                        {/* Operation C: Manage Community-wide Bans */}
                        <div className="bg-zinc-900 border border-zinc-850 p-6 rounded-2xl space-y-4">
                          <h3 className="text-sm font-bold text-red-500 flex items-center gap-1">
                            <Shield className="w-4 h-4 text-red-500" />
                            تجميد وإلحاق الرقابة بالمجتمعات المخالفة
                          </h3>

                          <div className="overflow-x-auto">
                            <table className="w-full text-right text-xs">
                              <thead>
                                <tr className="border-b border-zinc-800 text-zinc-500">
                                  <th className="pb-2">المجتمع</th>
                                  <th className="pb-2">المنشئ والمالك</th>
                                  <th className="pb-2">حالة الحظر</th>
                                  <th className="pb-2 text-left">تعديل الإجراء</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-850">
                                {communitiesList.map((comm) => (
                                  <tr key={comm.id} className="hover:bg-zinc-950/40">
                                    <td className="py-2.5 font-bold text-zinc-200">{comm.name}</td>
                                    <td className="py-2.5 font-mono text-zinc-400">{comm.owner}</td>
                                    <td className="py-2.5">
                                      {comm.isBanned ? (
                                        <span className="text-red-500 font-bold">● مجمد / محظور</span>
                                      ) : (
                                        <span className="text-green-500 font-semibold">● مفعل ونشط</span>
                                      )}
                                    </td>
                                    <td className="py-2.5 text-left">
                                      {comm.isBanned ? (
                                        <button
                                          onClick={() => handleAdminToggleCommunityBan(comm.id, false)}
                                          className="px-2.5 py-1 bg-green-950 hover:bg-green-900 text-green-400 rounded text-[10px] font-bold"
                                        >
                                          إعادة التفعيل
                                        </button>
                                      ) : (
                                        <button
                                          onClick={() => handleAdminToggleCommunityBan(comm.id, true)}
                                          className="px-2.5 py-1 bg-red-950 hover:bg-red-900 text-red-400 rounded text-[10px] font-bold"
                                        >
                                          حظر المجتمع 🚫
                                        </button>
                                      )}
                                    </td>
                                  </tr>
                                ))}

                                {communitiesList.length === 0 && (
                                  <tr>
                                    <td colSpan={4} className="py-4 text-center text-zinc-600">لا يوجد مجتمعات منشأة على قاعدة البيانات.</td>
                                  </tr>
                                )}
                              </tbody>
                            </table>
                          </div>
                        </div>

                      </div>
                    )}
                  </div>
                )}

              </div>
            )}

          </div>

          {/* Right Information Sidebar Panel (Vibrant Palette details matching: join requests, community metrics) */}
          {selectedCommunity && (
            <aside className="w-64 bg-[#121212] border-r border-zinc-800 p-5 flex flex-col gap-6 overflow-y-auto shrink-0 hidden lg:flex">
              
              {/* Point Indicator balance */}
              <div className="bg-orange-600 p-5 rounded-2xl flex flex-col items-center gap-1 select-none shadow-lg shadow-orange-950/20 text-center">
                <span className="text-[9px] font-black uppercase tracking-widest text-orange-200">النقاط الإجمالية للنخبة</span>
                <span className="text-3xl font-black text-black leading-tight">{currentUser.points}</span>
                <span className="text-[10px] font-bold text-orange-200">نقود تطبيق Friends</span>
              </div>

              {/* Join Requests (Only visible to OWNER and ADMINS of this community) */}
              {(selectedCommunity.owner === currentUser.username || selectedCommunity.admins.includes(currentUser.username)) && (
                <div className="bg-zinc-900/50 rounded-2xl border border-zinc-800/80 p-4 space-y-3">
                  <h3 className="text-[10px] font-black text-orange-400 uppercase tracking-widest border-b border-zinc-800 pb-2">
                    طلبات انضمام جديدة ({selectedCommunity.joinRequests.length})
                  </h3>
                  
                  <div className="space-y-2.5">
                    {selectedCommunity.joinRequests.map((reqUser) => (
                      <div key={reqUser} className="bg-zinc-950 p-3 rounded-xl border border-zinc-850">
                        <p className="text-xs font-bold text-zinc-200 mb-2 truncate">{reqUser}</p>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => handleModerateRequest(selectedCommunity.id, reqUser, "approve")}
                            className="flex-1 py-1 bg-orange-600 hover:bg-orange-500 text-black rounded text-[10px] font-black cursor-pointer"
                          >
                            قبول
                          </button>
                          <button 
                            onClick={() => handleModerateRequest(selectedCommunity.id, reqUser, "refuse")}
                            className="flex-1 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 rounded text-[10px] font-bold cursor-pointer"
                          >
                            رفض
                          </button>
                        </div>
                      </div>
                    ))}

                    {selectedCommunity.joinRequests.length === 0 && (
                      <p className="text-[10px] text-zinc-650 text-center">لا توجد طلبات معلقة.</p>
                    )}
                  </div>
                </div>
              )}

              {/* Members of Community */}
              <div className="bg-zinc-900/40 rounded-2xl border border-zinc-800 p-4 space-y-3">
                <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest border-b border-zinc-800 pb-2">
                  الأعضاء داخل المجتمع ({selectedCommunity.members.length})
                </h3>

                <div className="space-y-2 max-h-[250px] overflow-y-auto no-scrollbar">
                  {selectedCommunity.members.map((memberUsername) => {
                    const isOwner = selectedCommunity.owner === memberUsername;
                    const isAdmin = selectedCommunity.admins.includes(memberUsername);
                    const isThisMe = memberUsername.toLowerCase() === currentUser.username.toLowerCase();
                    
                    return (
                      <div key={memberUsername} className="flex items-center justify-between gap-2 p-1.5 hover:bg-zinc-950/40 rounded-lg">
                        <p className="text-xs font-semibold text-zinc-300 truncate font-mono">
                          {memberUsername}
                          {isOwner ? (
                            <span className="text-[8px] bg-amber-500/10 text-amber-500 p-0.5 rounded ml-1 font-bold">تاج</span>
                          ) : isAdmin ? (
                            <span className="text-[8px] bg-yellow-500/10 text-yellow-500 p-0.5 rounded ml-1 font-bold">مشرف</span>
                          ) : null}
                        </p>

                        {/* Administrative Kick / Ban Controls */}
                        {(selectedCommunity.owner === currentUser.username || selectedCommunity.admins.includes(currentUser.username)) && !isThisMe && (
                          <div className="flex gap-1 shrink-0">
                            
                            {/* OWNER actions: Toggle dynamic Admin promotion for member */}
                            {selectedCommunity.owner === currentUser.username && !isOwner && (
                              isAdmin ? (
                                <button
                                  onClick={() => handleConfigureCommunityAdmin(memberUsername, "demote")}
                                  className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-orange-500 rounded"
                                  title="إلغاء صلاحية أدمن"
                                >
                                  <UserMinus className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <button
                                  onClick={() => handleConfigureCommunityAdmin(memberUsername, "promote")}
                                  className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-amber-500 rounded"
                                  title="تعيين أدمن للمجتمع"
                                >
                                  <UserCheck className="w-3.5 h-3.5" />
                                </button>
                              )
                            )}

                            {/* OWNER or ADMIN action: Kick member */}
                            <button
                              onClick={() => handleKickMember(memberUsername)}
                              className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-red-500 rounded"
                              title="حذف عضو من المجتمع"
                            >
                              <MinusSquareIcon />
                            </button>

                            {/* OWNER or ADMIN action: Ban member completely */}
                            <button
                              onClick={() => handleBanMember(memberUsername)}
                              className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-purple-500 rounded"
                              title="حظر عضو نهائياً"
                            >
                              <ShieldAlert className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Bottom Quick Help */}
              <div className="mt-auto text-[10px] text-zinc-600 space-y-2 border-t border-zinc-900 pt-4">
                <p className="flex items-center gap-1">
                  <HelpCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>الرمز السري العام للإدارة: 1911</span>
                </p>
                <p>صاحب السيرفر المالك الرئيسي: admin الرمز: ahmad199231</p>
              </div>

            </aside>
          )}

        </div>

      </main>

        </div>

        {/* Soft simulated Android navigation keys */}
        {deviceModel !== "fullscreen" && (
          <div className="w-full h-10 bg-[#121212] flex items-center justify-around border-t border-zinc-900 shrink-0 z-40 relative px-10">
            {/* Soft Android Buttons */}
            <button 
              type="button"
              onClick={() => { setSelectedCommunity(null); setSelectedFriendUsername(null); }}
              className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-orange-500 rounded-full transition cursor-pointer"
              title="رجوع / شاشة الدردشة الرئيسية"
            >
              <svg className="w-5 h-5 mx-auto" fill="currentColor" viewBox="0 0 24 24">
                <path d="M14 7l-5 5 5 5V7z" />
              </svg>
            </button>

            <button 
              type="button"
              onClick={() => { setSelectedCommunity(null); setSelectedFriendUsername(null); setActiveSubTab("communities"); }}
              className="p-1 hover:bg-zinc-800 text-zinc-550 hover:text-orange-500 rounded-full transition cursor-pointer"
              title="الشبكة المستكشفة"
            >
              <svg className="w-5 h-5 mx-auto" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="6" />
              </svg>
            </button>

            <button 
              type="button"
              onClick={() => { setActiveSubTab("profile"); }}
              className="p-1 hover:bg-zinc-805 text-zinc-650 hover:text-orange-500 rounded-full transition cursor-pointer"
              title="الضبط ومراكز الإعدادات"
            >
              <svg className="w-4 h-4 mx-auto" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <rect x="6" y="6" width="12" height="12" rx="2" />
              </svg>
            </button>
          </div>
        )}

      </div>

    </div>
  );
}

// Custom minus icon fallback to respect constraints beautifully
function MinusSquareIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-minus-square w-3.5 h-3.5">
      <rect width="18" height="18" x="3" y="3" rx="2" />
      <path d="M8 12h8" />
    </svg>
  );
}
