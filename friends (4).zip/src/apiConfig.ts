/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const API_BASE_URL = (() => {
  if (typeof window !== "undefined") {
    const origin = window.location.origin;
    // Under Capacitor on Android, origin starts with 'http://localhost' or 'capacitor://'
    // Also check if window.Capacitor is present
    const isCapacitor = 
      (window as any).Capacitor || 
      origin.startsWith("capacitor://") || 
      (origin.startsWith("http://localhost") && window.location.port !== "3000");
    
    if (isCapacitor) {
      // Pre-configured production cloud run server backend 
      return "https://ais-pre-cfwsuqyzelcffzr5b4qnbh-159420781556.europe-west2.run.app";
    }
  }
  return "";
})();

export const getApiUrl = (path: string): string => {
  const normPath = path.startsWith("/") ? path : `/${path}`;
  return `${API_BASE_URL}${normPath}`;
};
