/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { LogIn, KeyRound, User as UserIcon, AlertCircle, Phone, Sparkles, CheckCircle2, Eye, EyeOff } from "lucide-react";
import { User } from "../types";
import { getApiUrl } from "../apiConfig";

interface AuthScreenProps {
  onAuthSuccess: (user: User) => void;
}

export default function AuthScreen({ onAuthSuccess }: AuthScreenProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register" | "recover">("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Form Fields
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [avatar, setAvatar] = useState("");
  const [statusText, setStatusText] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError("يرجى إدخال اسم المستخدم وكلمة المرور!");
      return;
    }
    setError("");
    setLoading(true);

    try {
      const res = await fetch(getApiUrl("/api/login"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim(), password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "خطأ أثناء تسجيل الدخول");
      }

      localStorage.setItem("friends_user", JSON.stringify(data.user));
      onAuthSuccess(data.user);
    } catch (err: any) {
      setError(err.message || "اسم المستخدم أو كلمة المرور غير صحيحة!");
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!username.trim() || !password || !phone.trim() || !confirmPassword) {
      setError("جميع البيانات إجبارية بما فيها رقم الهاتف وتأكيد كلمة المرور!");
      return;
    }

    if (username.trim().toLowerCase() === "admin") {
      setError("اسم المستخدم 'admin' محجوز للإدارة فقط!");
      return;
    }

    if (password !== confirmPassword) {
      setError("كلمات المرور غير متطابقة!");
      return;
    }

    if (password.length < 5) {
      setError("تأكيد الأمان: يجب ألا تقل كلمة المرور عن 5 خانات!");
      return;
    }

    setLoading(true);

    // Dynamic Avatar generation based on username
    const generatedAvatar = avatar.trim() || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(username.trim())}`;
    
    try {
      const res = await fetch(getApiUrl("/api/register"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          password,
          phone: phone.trim(),
          avatar: generatedAvatar,
          status: statusText.trim() || "مستكشف جديد في تطبيق Friends! 🧡"
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "خطأ في إنشاء الحساب");
      }

      setSuccess("تم إنشاء حسابك بنجاح! جاري توجيهك للمنصة...");
      
      // Auto login
      setTimeout(() => {
        localStorage.setItem("friends_user", JSON.stringify(data.user));
        onAuthSuccess(data.user);
      }, 1500);

    } catch (err: any) {
      setError(err.message || "فشلت عملية التسجيل. اسم المستخدم قد يكون مكرراً!");
    } finally {
      setLoading(false);
    }
  };

  const handleRecover = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!username.trim() || !phone.trim() || !password) {
      setError("يرجى إكمال الحقول الثلاثة: اسم المستخدم، ورقم الهاتف، والرمز الجديد!");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch(getApiUrl("/api/recover"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          phone: phone.trim(),
          newPassword: password
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "فشل استرجاع الحساب");
      }

      setSuccess("رائع! تمت استعادة حسابك بنجاح وتعيين الرمز الجديد. يرجى الدخول الآن.");
      setTimeout(() => {
        setActiveTab("login");
        setPassword("");
        setError("");
        setSuccess("");
      }, 2500);

    } catch (err: any) {
      setError(err.message || "معلومات الاستعادة المدخلة غير صحيحة!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      style={{ 
        backgroundImage: "linear-gradient(rgba(9, 9, 11, 0.9), rgba(9, 9, 11, 0.9)), url('/src/assets/images/friends_bg_1780026777426.png')",
        backgroundSize: "cover",
        backgroundPosition: "center"
      }}
      className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans w-full h-full"
    >
      
      {/* Decorative Orbs resembling Vibrant Palette glow */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Main Container */}
      <div className="w-full max-w-md bg-zinc-900/90 border border-zinc-800 rounded-2xl shadow-2xl p-6 md:p-8 backdrop-blur-md relative z-10 transition-all duration-300">
        
        {/* App Logo */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-zinc-950/40 rounded-2xl shadow-lg mb-3 overflow-hidden border border-zinc-700">
            <img 
              src="/src/assets/images/friends_logo_1780026753737.png" 
              alt="Friends Icon" 
              className="w-16 h-16 object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-orange-500 to-amber-400 bg-clip-text text-transparent">
            Friends
          </h1>
          <p className="text-zinc-400 text-xs mt-1">تطبيق دردشة وعوالم مجتمعية حرة 🧡</p>
        </div>

        {/* Tab switchers (only visible for non-recovery) */}
        {activeTab !== "recover" && (
          <div className="flex bg-zinc-950 p-1 rounded-xl mb-6 border border-zinc-800" dir="rtl">
            <button
              onClick={() => { setActiveTab("login"); setError(""); setSuccess(""); }}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors cursor-pointer ${
                activeTab === "login" ? "bg-orange-600 text-white shadow" : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              onClick={() => { setActiveTab("register"); setError(""); setSuccess(""); }}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors cursor-pointer ${
                activeTab === "register" ? "bg-orange-600 text-white shadow" : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              حساب جديد
            </button>
          </div>
        )}

        {/* Alerts */}
        {error && (
          <div className="p-3.5 mb-5 bg-red-950/40 border border-red-800/60 rounded-xl text-red-200 text-xs flex items-center gap-2.5 text-right" dir="rtl">
            <AlertCircle className="w-4.5 h-4.5 text-red-500 shrink-0" />
            <span className="font-semibold leading-relaxed">{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3.5 mb-5 bg-green-950/40 border border-green-800/60 rounded-xl text-green-200 text-xs flex items-center gap-2.5 text-right" dir="rtl">
            <CheckCircle2 className="w-4.5 h-4.5 text-green-500 shrink-0" />
            <span className="font-semibold leading-relaxed">{success}</span>
          </div>
        )}

        {/* LOGIN FORM */}
        {activeTab === "login" && (
          <form onSubmit={handleLogin} className="space-y-4" dir="rtl">
            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                اسم المستخدم
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-3 pr-10 py-3 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right"
                  placeholder="أدخل اسم المستخدم بالإنجليزية"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-600">
                  <UserIcon className="w-5 h-5" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                رقم السري
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-3 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-650 focus:outline-none transition text-right"
                  placeholder="••••••••"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-600">
                  <KeyRound className="w-5 h-5" />
                </div>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 left-0 pl-3 flex items-center text-zinc-600 hover:text-zinc-400 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 active:from-orange-800 text-black font-black text-sm rounded-xl shadow-lg transition duration-200 cursor-pointer disabled:opacity-50 mt-2 flex items-center justify-center gap-2"
            >
              {loading ? "جاري تسجيل الدخول..." : "تسجيل الدخول الآمن"}
              <LogIn className="w-4 h-4" />
            </button>

            <div className="text-center pt-4 border-t border-zinc-800/60">
              <button
                type="button"
                onClick={() => { setActiveTab("recover"); setError(""); setSuccess(""); setPassword(""); }}
                className="text-xs font-semibold text-orange-400 hover:text-orange-500 transition cursor-pointer inline-flex items-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5" />
                نسيت كلمة المرور؟ استعادة بـرقم الهاتف المعرّف
              </button>
            </div>
          </form>
        )}

        {/* REGISTER FORM */}
        {activeTab === "register" && (
          <form onSubmit={handleRegister} className="space-y-4" dir="rtl">
            <p className="text-[10px] text-zinc-500 leading-relaxed text-right font-medium">
              ⚠️ يتم حفظ بيانات الحساب بالكامل محلياً وعلى سيرفر التطبيق الخاص فقط. تسجيل الدخول عبر Google أو الشبكات الخارجية ممنوع تماماً لخصوصيتك.
            </p>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                اسم المستخدم (إنجليزي - فريد) *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-3 pr-10 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right font-mono"
                  placeholder="e.g. jamil99"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-650">
                  <UserIcon className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                رقم الهاتف (إجباري للاستعادة) *
              </label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-3 pr-10 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right"
                  placeholder="05xxxxxxx"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-650">
                  <Phone className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                كلمة المرور *
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right"
                placeholder="••••••••"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                تأكيد كلمة المرور *
              </label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right"
                placeholder="••••••••"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                الحالة والتعريف الشخصي (اختياري)
              </label>
              <input
                type="text"
                value={statusText}
                onChange={(e) => setStatusText(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right"
                placeholder="مثال: من هواة برمجة الويب 🚀"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                رابط الصورة الشخصية (اختياري)
              </label>
              <input
                type="url"
                value={avatar}
                onChange={(e) => setAvatar(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-xs text-white placeholder-zinc-600 focus:outline-none transition text-left font-mono"
                placeholder="https://example.com/photo.png"
                dir="ltr"
              />
              <p className="text-[10px] text-zinc-500 text-right mt-1">تلميح: إذا تركته فارغاً سنقوم بإنتاج رمز تعبيري جميل لملفك تلائماً مع معرّفك.</p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 active:from-orange-800 text-black font-black text-sm rounded-xl shadow-lg transition duration-200 cursor-pointer disabled:opacity-50 mt-2 flex items-center justify-center gap-2"
            >
              {loading ? "جاري المعالجة..." : "تأكيد تسجيل الحساب"}
              <Sparkles className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* RECOVERY FORM */}
        {activeTab === "recover" && (
          <form onSubmit={handleRecover} className="space-y-4" dir="rtl">
            <div className="pb-2 border-b border-zinc-800">
              <h3 className="text-sm font-bold text-orange-400 text-right">استرجاع حساب بالهاتف</h3>
              <p className="text-[10px] text-zinc-500 text-right leading-relaxed mt-1">
                الرجاء مطابقة اسم الـمستخدم والـهاتف المسجلين مسبقاً لتغيير كلمة المرور الخاصة بك.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                اسم المستخدم للعملية
              </label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right"
                placeholder="اسم حسابك بدقة"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                رقم الهاتف المعرّف
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-650 focus:outline-none transition text-right"
                placeholder="رقم الهاتف الأساسي"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-right">
                رمز المرور الجديد المرغوب
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-orange-500 rounded-xl text-sm text-white placeholder-zinc-600 focus:outline-none transition text-right"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 text-black font-black text-sm rounded-xl shadow-lg transition duration-200 cursor-pointer disabled:opacity-50 mt-2"
            >
              {loading ? "جاري فحص الحساب ومطابقة الهاتف..." : "حفظ الرمز وتجاوز القديم"}
            </button>

            <button
              type="button"
              onClick={() => { setActiveTab("login"); setError(""); setSuccess(""); setPassword(""); }}
              className="w-full py-2.5 bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 font-bold text-xs rounded-xl transition duration-200 cursor-pointer"
            >
              العودة لشاشة الدخول الرئيسية
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
