/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { LogIn, KeyRound, User as UserIcon, AlertCircle, Phone } from "lucide-react";
import { getApiUrl } from "../apiConfig";

interface LoginModalProps {
  onLoginSuccess: (username: string) => void;
  onSwitchToRegister: () => void;
  onSwitchToRecover: () => void;
}

export default function LoginModal({ onLoginSuccess, onSwitchToRegister, onSwitchToRecover }: LoginModalProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError("يرجى إدخال اسم المستخدم وكلمة المرور!");
      return;
    }
    setError("");
    setLoading(true);

    try {
      const res = await fetch(getApiUrl("/api/login"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim(), password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "فشل تسجيل الدخول");
      }

      // Store in localStorage
      localStorage.setItem("friends_user", JSON.stringify(data.user));
      onLoginSuccess(data.user.username);
    } catch (err: any) {
      setError(err.message || "حدث خطأ غير متوقع");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-6 bg-zinc-900 border border-zinc-800 rounded-2xl shadow-xl">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-extrabold text-orange-500 tracking-tight flex items-center justify-center gap-2">
          <span>Friends</span>
          <span className="text-white text-lg font-light border-r border-zinc-700 pr-2">تسجيل الدخول</span>
        </h2>
        <p className="text-zinc-400 text-sm mt-2">مرحباً بك مجدداً في مجتمعك المفضل</p>
      </div>

      {error && (
        <div className="p-3 mb-4 bg-red-950/40 border border-red-800/60 rounded-xl text-red-200 text-sm flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-zinc-300 mb-1.5 align-right text-right">
            اسم المستخدم
          </label>
          <div className="relative">
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full pl-3 pr-10 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500 transition text-right"
              placeholder="مثال: admin أو salem"
              dir="rtl"
            />
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-500">
              <UserIcon className="w-5 h-5" />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-zinc-300 mb-1.5 align-right text-right">
            كلمة المرور
          </label>
          <div className="relative">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-3 pr-10 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500 transition text-right"
              placeholder="••••••••"
              dir="rtl"
            />
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-500">
              <KeyRound className="w-5 h-5" />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-bold rounded-xl shadow-lg shadow-orange-950/20 flex items-center justify-center gap-2 transition duration-200 cursor-pointer disabled:opacity-50"
        >
          {loading ? "جاري التحقق..." : "دخول"}
          <LogIn className="w-5 h-5" />
        </button>
      </form>

      <div className="mt-6 pt-5 border-t border-zinc-800/80 text-center space-y-3">
        <button
          onClick={onSwitchToRecover}
          className="text-sm font-semibold text-orange-400 hover:text-orange-500 flex items-center justify-center gap-1.5 mx-auto transition cursor-pointer"
        >
          <Phone className="w-4 h-4" />
          نسيت كلمة المرور؟ استعِد حسابك بالهاتف
        </button>

        <p className="text-sm text-zinc-400">
          ليس لديك حساب؟{" "}
          <button
            onClick={onSwitchToRegister}
            className="text-orange-500 hover:underline cursor-pointer font-bold"
          >
            إنشاء حساب جديد
          </button>
        </p>
      </div>
    </div>
  );
}
