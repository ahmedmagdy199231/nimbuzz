/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  username: string;
  phone: string;
  avatar: string;
  status: string;
  points: number;
  isBanned: boolean;
  isModerator: boolean;
  createdAt: string;
}

export interface PrivateMessage {
  id: string;
  from: string;
  to: string;
  text: string;
  timestamp: string;
}

export interface Community {
  id: string; // usually clean slug or name
  name: string;
  description: string;
  owner: string;
  members: string[]; // usernames
  admins: string[];  // usernames
  banList: string[]; // usernames
  joinRequests: string[]; // usernames
  isBanned: boolean;
}

export interface CommunityMessage {
  id: string;
  communityId: string;
  sender: string;
  text: string;
  timestamp: string;
}

export interface VoiceStreamState {
  communityId: string;
  participants: {
    username: string;
    isSpeaking: boolean;
    isMuted: boolean;
    canSpeak: boolean;
  }[];
}
